# CLAUDE_TASK.md — Stratosphere: security hardening, CI/CD and reliability

You are Claude Code working in `deyaayush2006-coder/STRATOSPHERE`. This file is the complete brief. The exact code you need is already written and tested. It is in **Appendix A** at the end of this file, as 19 git commits (mbox format) that you apply with `git am`.

Read sections 1–3 before touching anything. Section 4 explains every commit, so you can resolve conflicts or rebuild a commit by hand if a patch does not apply.

---

## 0. Outcome you are aiming for

You are done when all of these are true:

- There is a new branch `hardening/security-ci-reliability` off the latest `main` with **20 atomic commits**: the 19 from Appendix A, plus 1 lockfile commit you create.
- These all pass locally:
  - `npm run lint` (0 errors)
  - `npm run test:unit` (25 tests)
  - `npm run test:db` (16 tests, if you can run Postgres)
  - `npm run build`
  - `npm run test:smoke` against a local `next start` (8 tests)
- The branch is pushed and a PR into `main` is open, with the description from section 6.
- Nothing was changed in the production Supabase project or the Vercel project unless the owner explicitly approved it in this session (see rule 3).
- You end with the report described in section 8.

---

## 1. Context

**Project.** Stratosphere is the website of the Aerospace Club of Jadavpur University. It has a public site plus an admin CMS ("Control Tower").
- **Stack:** Next.js 15 (App Router, server actions), React 19, Tailwind 4, Supabase (Postgres + Auth + Storage), deployed on Vercel.
- **Repo:** `github.com/deyaayush2006-coder/STRATOSPHERE`. Production branch is `main`; Vercel auto-deploys every push to it.
- **Live site:** `https://stratosphere-zeta.vercel.app`
- **Supabase project:** "Stratosphere", ref `ldchcptirabijgahqrxk`.
- **Vercel project:** `stratosphere`.

**Owner.** Aayush, the student who built it. He will use this project as evidence for a WebOps admin role where reviewers grade PR quality: a feature branch (not `main`), atomic commits and clear messages. **Keep the history clean.** No "final", "complete" or "new version" commit messages.

**How content flows:**
- `lib/content.js` → `readContent(client)` reads every section from Supabase. If anything errors, it falls back to bundled defaults in `data.js` / `lib/defaults.js`.
- The public site uses the anon key through `lib/supabase/public.js` and is ISR-cached (`revalidate = 60` in `app/(site)/layout.jsx`).
- The admin panel lives in `app/admin/`.
  - Its server actions (`app/admin/actions.js`) check `requireStaff()` / `requireAdmin()` and write as the signed-in staff user, so RLS applies.
  - Account management uses the service role (`lib/supabase/admin.js`).
- The contact form (`lib/send-message.js`) inserts through the service role, with a honeypot field and rate limits.
- `middleware.js` hides `/admin` behind `NEXT_PUBLIC_ADMIN_PATH` and refreshes Supabase sessions.

**What a full audit found:**

1. **CRITICAL — anyone could become admin.** The `handle_new_user` trigger gave every new auth user an *active* profile, and took `role` from `raw_user_meta_data`, which the person signing up controls. So `supabase.auth.signUp({ email, password, options: { data: { role: "admin" } } })` with the public anon key created an active admin.
   - This was reproduced on a local database built from migrations 0001–0006: the result was `role=admin, active=true`.
   - Production currently has only 2 accounts, both admins created by the owner, so there is no sign of exploitation.
   - Whether public sign-ups are enabled in Supabase Auth could not be checked.
2. **Profile enumeration.** Policy `profiles_read` let *any* authenticated user read every staff profile (names, emails, roles).
3. **Member emails.** `cohort_members` is publicly readable, including the `email` column (27 of 54 rows have one).
   - The app already strips emails before they reach the browser (`withoutMemberEmails` in `lib/content.js`), but anyone with the anon key could still query the column directly.
4. **Admin saves could lose data.** `replaceCollection` deletes rows, then upserts, then inserts, with no transaction. A failure after the delete lost rows.
5. **Supabase advisor warnings:**
   - `is_staff()`, `is_admin()` and `handle_new_user()` are SECURITY DEFINER functions executable over `/rest/v1/rpc`.
   - `touch_updated_at()` has a mutable `search_path`.
   - Leaked-password protection is off.
6. **Storage.** A public SELECT policy on `storage.objects` let anyone list every file in the `media` bucket, and the bucket accepted SVG uploads.
7. **No security headers**, and `eslint: { ignoreDuringBuilds: true }` was set.
8. **No CI.** There was no `.github/`, no tests, no lint script, and pushes to `main` went straight to production.
9. **Migrations are untracked.** They were run by hand in the SQL editor; `list_migrations` on the project is empty.
10. **Copy.** The footer showed template "Office hours" (Mon–Fri 9–6), and the archive line read "kept on record, oldest still readable". Both are template filler.
11. **Dependencies.**
    - Next 15.5.25 and sharp had advisories; `npm audit fix` moves Next to 15.5.27.
    - One "high" advisory remains: the postcss bundled inside `next@15`, which is build-time only. It needs Next 16.
    - Next/React are already past the December 2025 React Server Components RCE fixes (`next@15.5.x`, `react@19.2.x`).

**What was verified before handing this to you.** These results came from a sandbox with all 19 commits applied:
- lint is clean;
- 25 unit tests, 16 database (RLS) tests on Postgres 16 and 8 smoke tests against `next start` all pass;
- `next build` succeeds.

---

## 2. Hard rules

1. **Never commit or push to `main`.** Work only on `hardening/security-ci-reliability`. Merging is the owner's job.
2. **Never edit an applied migration** (`supabase/migrations/0001`–`0006`). Database changes go in new numbered files only.
3. **Do not change production** unless the owner explicitly says yes in this session. That means the Supabase project `ldchcptirabijgahqrxk` (no migrations, no SQL writes, no Auth settings) and the Vercel project (no env changes, no settings, no deploys).
   - If the Supabase MCP is connected and the owner approves, you may apply **0007 only** (see step 7).
   - **Never apply 0008 before the new app version is live.** The old code selects `cohort_members(*)`, which errors once anon loses the `email` column, and then the whole site falls back to defaults.
4. **No secrets anywhere:** not in commits, logs or the PR text. Never print env values.
5. **Keep commits atomic** with Conventional Commit messages. Keep the `Co-authored-by` trailers that are already in the patches.
6. If a test fails, **fix the cause**. Do not skip, delete or weaken a test to get green. Do not add retries to hide flakiness.
7. Keep diffs focused. Do not reformat unrelated files.

---

## 3. Step-by-step

### Step 1 — Sync and branch
```bash
git checkout main && git pull --ff-only
git checkout -b hardening/security-ci-reliability
git config user.name >/dev/null || git config user.name "Aayush Dey"
```
The patches were made against `main` at commit `a8f9c24` ("complete"). If `main` has moved, carry on; `--3way` handles most drift.

### Step 2 — Apply the 19 commits from Appendix A
If this file is in the repo root as `CLAUDE_TASK.md`, extract the mbox with a script. **Do not retype it.**
```bash
awk '/^STRATOSPHERE-MBOX-BEGIN$/{f=1;next} /^STRATOSPHERE-MBOX-END$/{f=0} f' CLAUDE_TASK.md > /tmp/stratosphere.mbox
grep -c '^From [0-9a-f]\{40\} ' /tmp/stratosphere.mbox   # must print 19
git am --3way /tmp/stratosphere.mbox
```
- **If `git am` stops on a conflict:**
  1. Resolve it by keeping the intent described in section 4 for that commit.
  2. Run `git add <files>`, then `git am --continue`.
  3. If a hunk is hopeless, run `git am --skip`, re-implement that commit by hand from its patch text in Appendix A, and commit it with the same message.
- **If this file was pasted into chat rather than saved in the repo:** ask the owner to add it to the repo root first (GitHub → Add file → Upload files). Retyping 90 KB of patch by hand invites mistakes.
- The task file itself must not end up in the PR. If it is committed on `main`, remove it in the last commit (step 5).

### Step 3 — Lockfile and dependency patches (commit #20)
The patches change `package.json` but deliberately leave out `package-lock.json`, which is too big to embed. Regenerate it:
```bash
npm install
npm audit fix --omit=dev        # moves next to >=15.5.27 and patches sharp; never use --force
npm ls >/dev/null && echo "dependency tree ok"
npm audit --omit=dev            # expect only the postcss-inside-next advisory (needs Next 16)
git add package.json package-lock.json
git commit -m "build: regenerate lockfile for test tooling and patched next/sharp"
```
If `npm audit fix` wants `--force` or a major upgrade, do not do it. That is follow-up F1.

### Step 4 — Verify everything
```bash
npm run lint          # 0 errors
npm run test:unit     # 25 passed
```
**Database tests** need a disposable Postgres (version 14 or later; CI uses 17). Use whichever works:
```bash
# Docker
docker run -d --name strat-pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres:17 && sleep 5
# or apt (Ubuntu)
sudo apt-get install -y postgresql && sudo pg_ctlcluster $(ls /usr/lib/postgresql) main start \
  && sudo -u postgres psql -c "alter user postgres password 'postgres'"

TEST_DATABASE_URL=postgres://postgres:postgres@127.0.0.1:5432/postgres npm run test:db   # 16 passed
```
If no Postgres is possible in your environment, say so in the report. The `Database security (RLS)` job in CI will run these tests on the PR.

**Build:**
```bash
NEXT_TELEMETRY_DISABLED=1 npm run build
```
If the build fails with `Failed to fetch font ... fonts.googleapis.com`, your sandbox has no access to Google Fonts. That is not a code bug. Mock the fonts for local verification only:
```bash
cat > /tmp/font-mocks.cjs <<'JS'
const face = (family, weight) => `/* latin */
@font-face { font-family: '${family}'; font-style: normal; font-weight: ${weight}; font-display: swap; src: url(https://fonts.gstatic.com/s/mock/${family.replace(/ /g, "")}.woff2) format('woff2'); unicode-range: U+0000-00FF; }`;
module.exports = {
  "https://fonts.googleapis.com/css2?family=Geist:wght@100..900&display=swap": face("Geist", "100 900"),
  "https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@100..800&display=swap": face("JetBrains Mono", "100 800"),
  "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300..700&display=swap": face("Space Grotesk", "300 700"),
};
JS
NEXT_FONT_GOOGLE_MOCKED_RESPONSES=/tmp/font-mocks.cjs NEXT_TELEMETRY_DISABLED=1 npm run build
```
**Smoke tests** against a local production server:
```bash
npx next start -p 3100 & sleep 6
SMOKE_URL=http://localhost:3100 npm run test:smoke     # 8 passed
curl -s -o /dev/null -w "%{http_code}\n" "http://localhost:3100/events/$(curl -s http://localhost:3100/sitemap.xml | grep -o '/events/[^<]*' | head -1 | cut -d/ -f3)/ics"
kill %1
```
Use `SMOKE_URL`, never `BASE_URL`: Vitest overwrites `process.env.BASE_URL` with `/`.

Only clean up your own artefacts afterwards: `docker rm -f strat-pg`, and kill the server you started. Do not touch anything else.

### Step 5 — Remove this brief from the branch
If `CLAUDE_TASK.md` is tracked in git, delete it in its own commit:
```bash
git rm CLAUDE_TASK.md && git commit -m "chore: remove task brief"
```

### Step 6 — Push and open the PR
```bash
git push -u origin hardening/security-ci-reliability
```
Open a PR into `main` titled **"Security hardening, CI/CD pipeline and reliability fixes"**, using the body in section 6. Use `gh pr create` if available; otherwise give the owner the compare link `https://github.com/deyaayush2006-coder/STRATOSPHERE/compare/main...hardening/security-ci-reliability`. **Do not merge.**

### Step 7 — Production database (only with explicit owner approval)
Ask the owner first, in plain words:

> "Apply migration 0007 to the production Supabase project now? It closes the admin sign-up hole. Side effect: until this PR is deployed, accounts created in Control Tower start suspended."

- **If they say yes and a Supabase MCP is connected:** apply the exact contents of `supabase/migrations/0007_auth_and_rls_hardening.sql` to project `ldchcptirabijgahqrxk`, then check the result with read-only SQL:
```sql
select proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
 where n.nspname in ('public','private') and proname in ('is_staff','is_admin','handle_new_user');
-- expect private.is_staff, private.is_admin, public.handle_new_user only
select count(*) from pg_policies where schemaname in ('public','storage');   -- expect 25
```
- **If they say no, or there is no MCP:** tell them to paste the file into Supabase → SQL Editor → Run.
- **Never run 0008 here.** It only goes in after the PR is merged and the new deploy is confirmed live (section 5).

### Step 8 — Report back
Use the format in section 8.

---

## 4. The 19 commits — what each does and why

The commit order matters: several commits build on earlier ones. Each entry below is the spec. If you rebuild a commit by hand, its tests are the acceptance criteria.

1. **`test(db): add Supabase stub and RLS test harness for plain Postgres`**
   - `tests/db/supabase-stub.sql` creates the Supabase pieces the migrations need:
     - roles `anon`, `authenticated`, `service_role` and `supabase_auth_admin`;
     - a minimal `auth.users` table and `auth.uid()` / `auth.role()` / `auth.jwt()`, which read `request.jwt.claims`;
     - a minimal `storage.buckets` / `storage.objects`;
     - Supabase's default grants.
   - `tests/db/setup.mjs`:
     - `buildDatabase(adminUrl)` creates a throwaway database, applies the stub and every migration in order, and seeds data. The seed covers an admin, an editor, a suspended editor and an outsider who self-signed-up asking for admin, plus published and draft rows, a member with an email, a contact message and a storage object.
     - `as(db, role, sub, sql)` runs one statement as an API role inside a transaction that it rolls back.
2. **`fix(db): stop public sign-ups from becoming staff or admin (0007)`.** Migration `0007_auth_and_rls_hardening.sql` is safe to apply before or after the deploy.
   - Adds a `private` schema, which the Data API does not expose. It holds `private.is_staff()` and `private.is_admin()` (SECURITY DEFINER, `search_path = ''`), and all policies use `(select private.is_staff())` so the check is evaluated once per statement.
   - `handle_new_user()` now takes role and active status only from `raw_app_meta_data`, which only the service role can set: `role` is `admin` only if `app_metadata.role = 'admin'`, and `is_active = (app_metadata.staff = 'true')`. EXECUTE is revoked from `public`, `anon` and `authenticated`.
   - `profiles.is_active` now defaults to `false`, and `touch_updated_at()` gets `search_path = ''`.
   - Content tables:
     - Read policies are rebuilt for the `anon` role only. Announcements, events, achievements and projects require `published`; project parts require a published parent. Cohorts, cohort members and sections are readable.
     - One `*_staff_all` policy per table is created for `authenticated` users who pass `private.is_staff()`. A signed-in non-staff account therefore sees nothing.
     - The `media` table is now staff-only, because the public site never reads it.
   - `profiles`: an account can read its own row, staff can read all rows, and only admins can write.
   - Storage:
     - Listing (SELECT) and all writes on the `media` bucket are staff-only.
     - Public URLs keep working because the bucket is public, and a public bucket doesn't need a SELECT policy to serve files.
     - SVG is removed from the bucket's allowed MIME types.
   - Drops `public.is_staff()` and `public.is_admin()`.
3. **`fix(admin): mark new staff accounts via server-only app_metadata`.** In `createUser` (`app/admin/actions.js`), `user_metadata` now carries only `{ name }`, and `app_metadata` carries `{ staff: true, role }`.
4. **`fix(privacy): select member emails only for the admin panel (0008)`**
   - `lib/content.js` exports `PUBLIC_MEMBER_COLUMNS = "id, cohort_id, name, role, dept, image, linkedin, sort_order"`.
   - `readContent(client, { includePrivate = false } = {})` selects `*, cohort_members(${PUBLIC_MEMBER_COLUMNS})` by default, and `*, cohort_members(*)` only when `includePrivate` is set.
   - The admin callers pass `{ includePrivate: true }`: `app/admin/page.jsx` and both `readContent(supabase)` calls in `app/admin/actions.js`.
   - Migration `0008_member_email_privacy.sql` revokes SELECT on `cohort_members` from `anon` and grants it back column by column, without `email`. **It must be applied after this code is live.**
5. **`build: add Vitest, ESLint and pg; patch next and sharp advisories`**
   - New `package.json` scripts: `lint`, `test`, `test:unit`, `test:db`, `test:smoke`, plus `vercel-build` (`npm run lint && npm run test:unit && next build`). Vercel runs `vercel-build` instead of `build`, so a failing test fails the deploy.
   - New dev dependencies: `vitest`, `pg`, `eslint` 9, `eslint-config-next`, `@eslint/eslintrc`.
   - Adds `eslint.config.mjs` (flat config extending `next/core-web-vitals`), `vitest.config.mjs` (`@` alias; excludes smoke tests) and `vitest.smoke.config.mjs`.
   - Adds `tests/unit/fake-supabase.js`, an in-memory supabase-js query builder with `failOn` and `cascade` options.
   - Adds `tests/unit/content.test.js`: the public read never selects emails, only the admin read selects `*`, `getContent` strips emails, and the read falls back to defaults on a database error.
   - Adds `tests/db/rls.test.js` with 16 policy tests.
   - The lockfile is not in this commit; step 3 adds it.
6. **`fix(admin): restore deleted rows when a save fails halfway`**
   - `replaceCollection` and `replaceChildren` now snapshot the rows they are about to delete, plus, for parents, the children that the delete will cascade to.
   - If any later upsert or insert fails, they upsert the snapshot back and rethrow.
   - Tests in `tests/unit/admin-actions.test.js`:
     - a failure restores the deleted rows;
     - a removed cohort is restored together with its members;
     - a successful save deletes exactly the removed rows;
     - nothing is written without a staff session;
     - `createUser` puts `staff`/`role` in `app_metadata` and never in `user_metadata`;
     - editors cannot create accounts.
7. **`feat(security): add security headers and report-only CSP; lint during builds`**
   - `lib/security-headers.mjs` sets HSTS (2 years, includeSubDomains), `nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy` and COOP.
   - It also sets an **enforced** CSP of `frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'`, plus a full **Report-Only** CSP that allows self, the Supabase origin and `wss:`, with no `unsafe-eval` in production.
   - `next.config.mjs` applies these headers to `/(.*)`, sets `poweredByHeader: false` and removes `eslint.ignoreDuringBuilds`.
   - Covered by `tests/unit/security-headers.test.js`.
8. **`perf(middleware): refresh Supabase sessions only on the admin path`**
   - Public paths return `NextResponse.next()` with no auth round-trip.
   - The admin path (custom or `/admin`) still calls `withSession`.
   - The `/admin` → 404 rewrite still applies when a custom path is set.
9. **`test(contact): cover honeypot, validation, length caps and rate limit`**, in `tests/unit/send-message.test.js`.
10. **`feat: add error boundaries and robots.txt`.** Adds `app/error.jsx`, `app/global-error.jsx` and `app/robots.js`. `robots.js` allows everything and points to the sitemap. It deliberately does **not** list the admin path, because that would advertise it.
11. **`feat(events): add-to-calendar downloads and Event structured data`**
    - `lib/event-dates.js` parses the free-text labels editors type (for example "10–11 April 2026" and "10:00 AM - 5:00 PM", in IST +05:30). It returns `null` when a label can't be read, in which case the calendar link is hidden.
    - `eventIcs()` builds an RFC 5545 file.
    - New route `app/(site)/events/[slug]/ics/route.js`.
    - The event page shows an "Add to calendar" link for upcoming events and adds `Event` JSON-LD (with `<` escaped).
    - Covered by `tests/unit/event-dates.test.js`.
12. **`feat(seo): add Organization structured data`**, as JSON-LD in `app/layout.jsx`.
13. **`fix(copy): drop template office hours and archive filler; credit the site`**
    - The footer renders "Office hours" only when hours exist, and `data.js` now has `hours: []`.
    - The archive line now reads "N earlier achievements".
    - The footer says "Website by Aayush Dey", linking to his GitHub.
    - **Note:** production has 3 office-hour rows saved in the database `sections.contact` value. Those override the defaults, so the live footer keeps showing them until the owner clears them in Control Tower → Contact.
14. **`test(smoke): black-box HTTP checks for any deployment`.** `tests/smoke/site.test.mjs` runs against `SMOKE_URL` (with an optional `x-vercel-protection-bypass` header) and checks:
    - the home page returns 200 and sends the security headers, with no `X-Powered-By`;
    - OG, Twitter and Organization metadata are present;
    - **every email in the HTML also appears as a `mailto:` link**, which catches hidden leaks in the RSC payload (`@example.*` placeholders are ignored);
    - `robots.txt` and `sitemap.xml` are served, the first event page loads, and unknown paths return 404;
    - `/admin` returns 404 when `ADMIN_PATH` is custom.
15. **`ci: lint, unit, build, RLS, append-only migrations, secret scan, audit`** (`.github/workflows/ci.yml`). It runs on every PR and on pushes to `main`, with these jobs:
    - `check`: lint, unit tests, build;
    - `database`: a `postgres:17` service plus `npm run test:db`;
    - `migrations`: fails the PR if an existing migration file is modified, renamed or deleted;
    - `secrets`: gitleaks;
    - `audit`: blocks on critical advisories and warns on high.
16. **`ci: smoke-test every Vercel deployment and run a 30-minute uptime check`**
    - `deploy-smoke.yml` runs on GitHub `deployment_status` events, which Vercel sends for each deployment. It runs the smoke suite against the deployment URL and opens a `P0` issue if production fails.
    - `uptime.yml` runs every 30 minutes. It checks that the site and sitemap return 200, and that the anon key cannot read `contact_messages`, `profiles`, `media` or `cohort_members.email`.
    - It opens one `P0` issue and doesn't spam. It also keeps a free Supabase project from pausing.
    - The member-email check fails until 0008 is applied, and that failure is correct.
17. **`ci: add CodeQL, Dependabot and a PR template`.** CodeQL uses the security-and-quality queries and also runs weekly. Dependabot updates npm (minor/patch grouped) and GitHub Actions weekly.
18. **`chore: dedupe .gitignore, keep .env.example, mark seed-only env vars`.** Adds `!.env.example`, and comments that `ADMIN_*` is for local `npm run seed` only and never belongs on Vercel.
19. **`docs: security model, migrations, testing and CI/CD runbook`.** Updates `README.md` with the security model, the migration order table, testing commands, the CI/CD flow and the one-time setup.

---

## 5. Things only the owner can do

Include this checklist, unchanged, in your final report and in the PR description.

**Supabase dashboard**
- [ ] Authentication → Sign In / Providers: turn **off** "Allow new users to sign up". The admin panel creates accounts through the service role, so it keeps working.
- [ ] Authentication → turn on **Leaked password protection**.
- [ ] SQL Editor: run `supabase/migrations/0007_auth_and_rls_hardening.sql` **now**. It is safe before the deploy.
- [ ] After 0007, activate any account created in Control Tower before this PR is live (Users → active).
- [ ] **After the PR is merged and the new deploy is live:** run `supabase/migrations/0008_member_email_privacy.sql`. Then confirm the member list still shows on the live site.
- [ ] Control Tower → Contact: clear the 3 saved office-hour rows.
- [ ] Check the plan. On Free, the project pauses after about a week without activity (the uptime job prevents this) and there are no downloadable backups (see F6).

**Vercel**
- [ ] Delete env vars `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`. Only `supabase/seed.mjs` uses them, locally. Keep the password somewhere safe first.
- [ ] Open the first deployment log after merge and confirm it ran `vercel-build` (lint + unit tests). If it ran plain `next build`, set Settings → Build & Deployment → Build Command to `npm run vercel-build`.
- [ ] If Deployment Protection is on, go to Settings → Deployment Protection → Protection Bypass for Automation, and copy the secret to GitHub as `VERCEL_AUTOMATION_BYPASS_SECRET`.
- [ ] Optional: a cleaner domain than `stratosphere-zeta.vercel.app`.

**GitHub**
- [ ] Settings → Branches → protect `main`:
  - require a PR;
  - require these status checks: `Lint, unit tests, build`, `Database security (RLS)`, `Migrations are append-only`, `Secret scan`;
  - block force-pushes.
- [ ] Settings → Secrets and variables → Actions:
  - secrets: `VERCEL_AUTOMATION_BYPASS_SECRET` (if protection is on), `ADMIN_PATH`, `PROD_SUPABASE_ANON_KEY`;
  - variables: `PROD_URL` = `https://stratosphere-zeta.vercel.app`, `PROD_SUPABASE_URL` = `https://ldchcptirabijgahqrxk.supabase.co`.
- [ ] Merge the PR only when CI is green. From now on, every change goes through a branch and a PR.

---

## 6. PR description (use as-is)

```
## What
Security hardening, a full CI/CD pipeline and reliability fixes, from a complete audit.

## Why
- CRITICAL: public sign-ups became active admins (trigger trusted user_metadata). Fixed in 0007.
- Any signed-in account could read all staff profiles; SECURITY DEFINER helpers were callable over RPC.
- Member emails were readable with the anon key. Code now selects explicit columns; 0008 enforces it in the DB.
- Admin saves could silently lose rows if a step failed after the delete. Now restored.
- No security headers, no tests, no CI; pushes went straight to production.

## Database — ORDER MATTERS
1. 0007_auth_and_rls_hardening.sql: apply any time (safe before deploy).
2. Merge this PR → wait for the Vercel deploy → confirm it's live.
3. 0008_member_email_privacy.sql: apply ONLY after step 2.

## Verification
- npm run lint (0 errors) · test:unit (25) · test:db (16, Postgres) · build · test:smoke (8, local next start)
- New CI: lint/unit/build, RLS on Postgres 17, append-only migrations, gitleaks, npm audit, CodeQL
- Vercel: vercel-build runs lint + unit tests before next build
- Every deployment is smoke-tested; uptime + data-exposure check every 30 min

## Owner checklist
(paste section 5 of the brief here)
```

---

## 7. Follow-ups (separate PRs, not this one)

Each follow-up gets its own branch, tests and PR. Do not start them unless the owner asks.

- **F1 — Upgrade to Next 16.** This clears the remaining high advisory (the postcss bundled in next@15). Read the Next 16 upgrade guide, run the codemods, then re-run every test layer.
- **F2 — Enforce the full CSP.** Watch a preview deploy's console for Report-Only violations, adjust `contentSecurityPolicy()`, then move it to the enforced header. Add a smoke assertion for it.
- **F3 — Truly atomic admin saves.** Replace the snapshot-and-restore approach with one Postgres function per collection that does delete, upsert and insert inside a transaction. Make it SECURITY INVOKER so RLS still applies, and test it in `tests/db`.
- **F4 — Vercel Web Analytics and Speed Insights.** In the sandbox, `npm i @vercel/analytics @vercel/speed-insights` failed with ERESOLVE (a peer-dependency conflict). Pick versions that support React 19 and Next 15, add `<Analytics/>` and `<SpeedInsights/>` to `app/layout.jsx`, and allow their origins in the CSP.
- **F5 — Compress `/public/images`.** It is about 10 MB, with several JPGs over 500 KB (e.g. `images/memories/srijan-2026-launch-pad.jpg`, `images/hero/glider-flight-test.jpg`). Convert to WebP at a maximum width of 1920 px and quality around 80, and keep the filenames stable or update every reference.
- **F6 — Weekly database backup.** Add a GitHub Action that runs `pg_dump` with a `SUPABASE_DB_URL` secret (session pooler, read-only role if possible) and uploads an encrypted artifact with a short retention period.
- **F7 — Audit trail.** Add `updated_by uuid references auth.users` to the content tables, set by a trigger from `auth.uid()`, and show "last edited by" in Control Tower.
- **F8 — `CHANGELOG.md`.** Each merged PR adds a line.
- **F9 — Recruitment and join flow.** Top student teams run semester applications per sub-team (e.g. UF Swamp Launch).
  - Add a `recruitment` section with open/closed status per sub-team, an application form (service-role insert with honeypot and rate limits like the contact form) and a staff inbox in Control Tower.
  - Use a new migration with RLS: anon gets no reads, and only staff can read.
- **F10 — Sponsors marquee accessibility.** Copies after the first should be `aria-hidden`; this is partly done. Verify with a screen reader that each sponsor is announced once.

---

## 8. Final report format

When you finish, reply with exactly these sections:

1. **Branch and PR:** the branch name, the PR link (or compare link) and the commit count.
2. **Verification:** each command with its pass/fail count. Name anything you could not run and why (for example "no Postgres available, so the DB tests will run in CI").
3. **Deviations:** any commit you re-implemented by hand, any conflict you resolved and how, and anything you changed beyond Appendix A.
4. **Production:** whether 0007 was applied, by whom and how it was checked. Confirm that 0008 was **not** applied.
5. **Owner checklist:** section 5, unchanged.

---

## Appendix A — the 19 commits (git mbox, excluding package-lock.json)

Extract with the `awk` command in step 2. Everything between the two marker lines is a valid mbox for `git am`.

````text
STRATOSPHERE-MBOX-BEGIN
From d0fd7b126b8ed6ae2f4db2595e7f7de9783374a9 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 01/19] test(db): add Supabase stub and RLS test harness for
 plain Postgres

Co-authored-by: Claude <noreply@anthropic.com>
---
 tests/db/setup.mjs         | 79 ++++++++++++++++++++++++++++++++++++++
 tests/db/supabase-stub.sql | 54 ++++++++++++++++++++++++++
 2 files changed, 133 insertions(+)
 create mode 100644 tests/db/setup.mjs
 create mode 100644 tests/db/supabase-stub.sql

diff --git a/tests/db/setup.mjs b/tests/db/setup.mjs
new file mode 100644
index 0000000..7ab33fd
--- /dev/null
+++ b/tests/db/setup.mjs
@@ -0,0 +1,79 @@
+// Builds a throwaway database: Supabase stub + every migration in order + seed.
+import { readFileSync, readdirSync } from "node:fs";
+import { join } from "node:path";
+import pg from "pg";
+
+const ROOT = new URL("../../", import.meta.url).pathname;
+const MIGRATIONS = join(ROOT, "supabase/migrations");
+
+export const IDS = {
+  admin: "00000000-0000-4000-8000-0000000000a1",
+  editor: "00000000-0000-4000-8000-0000000000e1",
+  suspended: "00000000-0000-4000-8000-0000000000e2",
+  outsider: "00000000-0000-4000-8000-0000000000b1",
+};
+
+export async function buildDatabase(adminUrl, dbName = "strat_rls") {
+  const admin = new pg.Client({ connectionString: adminUrl });
+  await admin.connect();
+  await admin.query(`drop database if exists ${dbName} with (force)`);
+  await admin.query(`create database ${dbName}`);
+  await admin.end();
+
+  const url = new URL(adminUrl);
+  url.pathname = `/${dbName}`;
+  const db = new pg.Client({ connectionString: url.toString() });
+  await db.connect();
+
+  await db.query(readFileSync(join(ROOT, "tests/db/supabase-stub.sql"), "utf8"));
+  for (const file of readdirSync(MIGRATIONS).filter((f) => f.endsWith(".sql")).sort()) {
+    try {
+      await db.query(readFileSync(join(MIGRATIONS, file), "utf8"));
+    } catch (error) {
+      throw new Error(`Migration ${file} failed: ${error.message}`);
+    }
+  }
+
+  // Accounts as GoTrue would create them. Only app_metadata is trusted.
+  await db.query(
+    `insert into auth.users (id, email, raw_user_meta_data, raw_app_meta_data) values
+       ($1, 'admin@example.com',    '{"name":"Admin"}',  '{"staff":true,"role":"admin"}'),
+       ($2, 'editor@example.com',   '{"name":"Editor"}', '{"staff":true,"role":"editor"}'),
+       ($3, 'old@example.com',      '{"name":"Old"}',    '{"staff":true,"role":"editor"}'),
+       ($4, 'attacker@example.com', '{"name":"x","role":"admin"}', '{}')`,
+    [IDS.admin, IDS.editor, IDS.suspended, IDS.outsider]
+  );
+  await db.query(`update public.profiles set is_active = false where id = $1`, [IDS.suspended]);
+
+  await db.query(`
+    insert into public.announcements (slug, title, published) values ('live', 'Live', true), ('draft', 'Draft', false);
+    insert into public.projects (slug, title, published) values ('pub', 'Pub', true), ('hidden', 'Hidden', false);
+    insert into public.project_parts (project_id, slug, name)
+      select id, 'part-' || slug, 'Part' from public.projects;
+    insert into public.cohorts (year) values ('2026');
+    insert into public.cohort_members (cohort_id, name, email)
+      select id, 'Member', 'member@example.com' from public.cohorts;
+    insert into public.contact_messages (name, email, subject, message) values ('A', 'a@example.com', 'Hi', 'Secret message');
+    insert into storage.buckets (id, name, public) values ('media', 'media', true) on conflict do nothing;
+    insert into storage.objects (bucket_id, name) values ('media', 'team/photo.webp');
+  `);
+
+  return db;
+}
+
+// Run one statement as an API role with the given JWT subject, then roll back.
+export async function as(db, role, sub, sql, params = []) {
+  await db.query("begin");
+  try {
+    await db.query(`set local role ${role}`);
+    await db.query("select set_config('request.jwt.claims', $1, true)", [
+      JSON.stringify({ role, sub: sub ?? "" }),
+    ]);
+    const res = await db.query(sql, params);
+    return { rows: res.rows, count: res.rowCount };
+  } catch (error) {
+    return { error: error.message };
+  } finally {
+    await db.query("rollback");
+  }
+}
diff --git a/tests/db/supabase-stub.sql b/tests/db/supabase-stub.sql
new file mode 100644
index 0000000..8f688d8
--- /dev/null
+++ b/tests/db/supabase-stub.sql
@@ -0,0 +1,54 @@
+-- Minimal stand-in for the parts of Supabase that our migrations and RLS
+-- policies touch. Lets CI and local runs test policies on plain Postgres.
+do $$ begin
+  if not exists (select 1 from pg_roles where rolname = 'anon') then create role anon nologin noinherit; end if;
+  if not exists (select 1 from pg_roles where rolname = 'authenticated') then create role authenticated nologin noinherit; end if;
+  if not exists (select 1 from pg_roles where rolname = 'service_role') then create role service_role nologin noinherit bypassrls; end if;
+  if not exists (select 1 from pg_roles where rolname = 'supabase_auth_admin') then create role supabase_auth_admin nologin noinherit; end if;
+end $$;
+
+create schema if not exists auth;
+create schema if not exists storage;
+create schema if not exists extensions;
+
+create table if not exists auth.users (
+  id                 uuid primary key default gen_random_uuid(),
+  email              text,
+  raw_user_meta_data jsonb not null default '{}'::jsonb,
+  raw_app_meta_data  jsonb not null default '{}'::jsonb,
+  created_at         timestamptz not null default now()
+);
+
+create or replace function auth.uid() returns uuid language sql stable as $$
+  select nullif(current_setting('request.jwt.claims', true)::jsonb ->> 'sub', '')::uuid
+$$;
+create or replace function auth.role() returns text language sql stable as $$
+  select current_setting('request.jwt.claims', true)::jsonb ->> 'role'
+$$;
+create or replace function auth.jwt() returns jsonb language sql stable as $$
+  select coalesce(current_setting('request.jwt.claims', true), '{}')::jsonb
+$$;
+
+create table if not exists storage.buckets (
+  id text primary key, name text not null, owner uuid, public boolean default false,
+  file_size_limit bigint, allowed_mime_types text[],
+  created_at timestamptz default now(), updated_at timestamptz default now()
+);
+create table if not exists storage.objects (
+  id uuid primary key default gen_random_uuid(),
+  bucket_id text references storage.buckets (id), name text, owner uuid,
+  metadata jsonb, created_at timestamptz default now(), updated_at timestamptz default now(),
+  last_accessed_at timestamptz default now()
+);
+alter table storage.objects enable row level security;
+create or replace function storage.foldername(name text) returns text[] language sql immutable as $$
+  select (string_to_array(name, '/'))[1:array_length(string_to_array(name, '/'), 1) - 1]
+$$;
+
+-- Supabase's default privileges: API roles get table grants, RLS decides rows.
+grant usage on schema public, auth, storage, extensions to anon, authenticated, service_role;
+grant execute on all functions in schema auth to anon, authenticated, service_role;
+grant all on all tables in schema storage to anon, authenticated, service_role;
+alter default privileges in schema public grant all on tables    to anon, authenticated, service_role;
+alter default privileges in schema public grant all on sequences to anon, authenticated, service_role;
+alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
-- 
2.43.0


From 08a3af9c18df34d16cab992007698f6277e22970 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 02/19] fix(db): stop public sign-ups from becoming staff or
 admin (0007)

Co-authored-by: Claude <noreply@anthropic.com>
---
 .../0007_auth_and_rls_hardening.sql           | 156 ++++++++++++++++++
 1 file changed, 156 insertions(+)
 create mode 100644 supabase/migrations/0007_auth_and_rls_hardening.sql

diff --git a/supabase/migrations/0007_auth_and_rls_hardening.sql b/supabase/migrations/0007_auth_and_rls_hardening.sql
new file mode 100644
index 0000000..923ba15
--- /dev/null
+++ b/supabase/migrations/0007_auth_and_rls_hardening.sql
@@ -0,0 +1,156 @@
+-- 0007 — Auth and RLS hardening. Safe to apply before or after the app deploy.
+--
+-- Fixes:
+--   * Any account created through public sign-up became an ACTIVE staff
+--     profile, and took its role from user_metadata (which the person signing
+--     up controls), so `signUp({ data: { role: 'admin' } })` produced an admin.
+--     New profiles are now inactive editors unless the server (service role)
+--     sets app_metadata.staff / app_metadata.role, which users cannot edit.
+--   * Any signed-in account could read every staff profile.
+--   * is_staff() / is_admin() / handle_new_user() were SECURITY DEFINER
+--     functions callable through the public REST API (/rest/v1/rpc/...).
+--   * touch_updated_at() had a mutable search_path.
+--   * Anyone could list every file in the media bucket; SVG uploads allowed.
+--   * The media table (uploader ids, filenames) was publicly readable but the
+--     site never reads it.
+--
+-- Note: until the matching app change ships, accounts created from the admin
+-- panel start suspended. Activate them in Control Tower → Users.
+
+-- 1. Role helpers move to a schema the Data API does not expose.
+create schema if not exists private;
+revoke all on schema private from public;
+grant usage on schema private to anon, authenticated, service_role;
+
+create or replace function private.is_staff()
+returns boolean
+language sql
+stable
+security definer
+set search_path = ''
+as $fn$
+  select exists (
+    select 1 from public.profiles
+    where id = (select auth.uid()) and is_active
+  );
+$fn$;
+
+create or replace function private.is_admin()
+returns boolean
+language sql
+stable
+security definer
+set search_path = ''
+as $fn$
+  select exists (
+    select 1 from public.profiles
+    where id = (select auth.uid()) and is_active and role = 'admin'
+  );
+$fn$;
+
+revoke all on function private.is_staff() from public;
+revoke all on function private.is_admin() from public;
+grant execute on function private.is_staff() to anon, authenticated, service_role;
+grant execute on function private.is_admin() to anon, authenticated, service_role;
+
+-- 2. New accounts are never staff unless the server says so.
+alter table public.profiles alter column is_active set default false;
+
+create or replace function public.handle_new_user()
+returns trigger
+language plpgsql
+security definer
+set search_path = ''
+as $fn$
+begin
+  insert into public.profiles (id, name, email, role, is_active)
+  values (
+    new.id,
+    coalesce(nullif(new.raw_user_meta_data ->> 'name', ''), split_part(coalesce(new.email, ''), '@', 1)),
+    coalesce(new.email, ''),
+    case when new.raw_app_meta_data ->> 'role' = 'admin' then 'admin' else 'editor' end,
+    coalesce(new.raw_app_meta_data ->> 'staff' = 'true', false)
+  )
+  on conflict (id) do nothing;
+  return new;
+end;
+$fn$;
+
+revoke all on function public.handle_new_user() from public, anon, authenticated;
+grant execute on function public.handle_new_user() to supabase_auth_admin, service_role;
+
+-- 3. Pin search_path on the updated_at trigger.
+alter function public.touch_updated_at() set search_path = '';
+
+-- 4. Rebuild content policies. Public reads go to `anon` only; signed-in
+--    accounts see content only through the staff policy, so a non-staff
+--    account sees nothing at all.
+do $do$
+declare t text;
+begin
+  foreach t in array array[
+    'announcements', 'events', 'achievements', 'projects', 'project_parts',
+    'cohorts', 'cohort_members', 'sections', 'media', 'contact_messages'
+  ] loop
+    execute format('drop policy if exists %I on public.%I', t || '_read', t);
+    execute format('drop policy if exists %I on public.%I', t || '_staff_all', t);
+    execute format(
+      'create policy %I on public.%I for all to authenticated '
+      'using ((select private.is_staff())) with check ((select private.is_staff()))',
+      t || '_staff_all', t
+    );
+  end loop;
+
+  foreach t in array array['announcements', 'events', 'achievements', 'projects'] loop
+    execute format('create policy %I on public.%I for select to anon using (published)', t || '_read', t);
+  end loop;
+
+  foreach t in array array['cohorts', 'cohort_members', 'sections'] loop
+    execute format('create policy %I on public.%I for select to anon using (true)', t || '_read', t);
+  end loop;
+end
+$do$;
+
+create policy project_parts_read on public.project_parts
+  for select to anon
+  using (exists (
+    select 1 from public.projects p
+    where p.id = project_parts.project_id and p.published
+  ));
+
+drop policy if exists profiles_read on public.profiles;
+drop policy if exists profiles_admin_all on public.profiles;
+create policy profiles_read on public.profiles
+  for select to authenticated
+  using (id = (select auth.uid()) or (select private.is_staff()));
+create policy profiles_admin_all on public.profiles
+  for all to authenticated
+  using ((select private.is_admin())) with check ((select private.is_admin()));
+
+-- 5. Storage: public URLs keep working (public bucket); listing is staff-only.
+drop policy if exists media_objects_read on storage.objects;
+drop policy if exists media_objects_write on storage.objects;
+drop policy if exists media_objects_update on storage.objects;
+drop policy if exists media_objects_delete on storage.objects;
+
+create policy media_objects_read on storage.objects
+  for select to authenticated
+  using (bucket_id = 'media' and (select private.is_staff()));
+create policy media_objects_write on storage.objects
+  for insert to authenticated
+  with check (bucket_id = 'media' and (select private.is_staff()));
+create policy media_objects_update on storage.objects
+  for update to authenticated
+  using (bucket_id = 'media' and (select private.is_staff()))
+  with check (bucket_id = 'media' and (select private.is_staff()));
+create policy media_objects_delete on storage.objects
+  for delete to authenticated
+  using (bucket_id = 'media' and (select private.is_staff()));
+
+update storage.buckets
+   set allowed_mime_types = array['image/webp', 'image/jpeg', 'image/png', 'image/gif', 'image/avif']
+ where id = 'media';
+
+-- 6. Nothing references the old public helpers any more.
+drop function if exists public.is_staff();
+drop function if exists public.is_admin();
-- 
2.43.0


From 6d09d74c350bc40989f16eeaacdcdf959b82cbf5 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 03/19] fix(admin): mark new staff accounts via server-only
 app_metadata

Co-authored-by: Claude <noreply@anthropic.com>
---
 app/admin/actions.js | 5 ++++-
 1 file changed, 4 insertions(+), 1 deletion(-)

diff --git a/app/admin/actions.js b/app/admin/actions.js
index c66347b..b04b147 100644
--- a/app/admin/actions.js
+++ b/app/admin/actions.js
@@ -262,7 +262,10 @@ export async function createUser({ name, email, password, role }) {
     email,
     password,
     email_confirm: true,
-    user_metadata: { name, role: role === "admin" ? "admin" : "editor" },
+    user_metadata: { name },
+    // app_metadata can only be set with the service role, so the database
+    // trusts it (see migration 0007). user_metadata is user-editable.
+    app_metadata: { staff: true, role: role === "admin" ? "admin" : "editor" },
   });
 
   fail(error, "Could not create the account");
-- 
2.43.0


From ed11ddfc9ecd4014c352472548fa64408acca895 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 04/19] fix(privacy): select member emails only for the admin
 panel (0008)

Co-authored-by: Claude <noreply@anthropic.com>
---
 app/admin/actions.js                              |  4 ++--
 app/admin/page.jsx                                |  2 +-
 lib/content.js                                    | 14 ++++++++++++--
 supabase/migrations/0008_member_email_privacy.sql | 12 ++++++++++++
 4 files changed, 27 insertions(+), 5 deletions(-)
 create mode 100644 supabase/migrations/0008_member_email_privacy.sql

diff --git a/app/admin/actions.js b/app/admin/actions.js
index b04b147..0ac3127 100644
--- a/app/admin/actions.js
+++ b/app/admin/actions.js
@@ -206,7 +206,7 @@ export async function saveSection(key, value) {
 
   refreshSite();
 
-  const content = await readContent(supabase);
+  const content = await readContent(supabase, { includePrivate: true });
   return content[key];
 }
 
@@ -224,7 +224,7 @@ export async function resetSection(key) {
 
   refreshSite();
 
-  const content = await readContent(supabase);
+  const content = await readContent(supabase, { includePrivate: true });
   return content[key];
 }
 
diff --git a/app/admin/page.jsx b/app/admin/page.jsx
index aa0fd47..928d3dd 100644
--- a/app/admin/page.jsx
+++ b/app/admin/page.jsx
@@ -33,7 +33,7 @@ export default async function AdminPage() {
   const staff = await getStaff();
   if (!staff) return <LoginScreen />;
 
-  const content = await readContent(await createClient());
+  const content = await readContent(await createClient(), { includePrivate: true });
 
   return <Dashboard user={staff} initialContent={content} />;
 }
diff --git a/lib/content.js b/lib/content.js
index 26ef357..eac3874 100644
--- a/lib/content.js
+++ b/lib/content.js
@@ -46,7 +46,11 @@ async function fetchTable(client, table, select, map, key) {
   return orDefault((data ?? []).map(map), key);
 }
 
-export async function readContent(client) {
+// Columns the public site may read. Emails stay server-side for staff only, and
+// migration 0008 makes the database enforce this for the anon role too.
+export const PUBLIC_MEMBER_COLUMNS = "id, cohort_id, name, role, dept, image, linkedin, sort_order";
+
+export async function readContent(client, { includePrivate = false } = {}) {
   const bundled = { ...DEFAULT_CONTENT };
 
   if (!client) return finish(bundled);
@@ -59,7 +63,13 @@ export async function readContent(client) {
         fetchTable(client, "events", "*", eventFromRow, "events"),
         fetchTable(client, "achievements", "*", achievementFromRow, "achievements"),
         fetchTable(client, "projects", "*, project_parts(*)", projectFromRow, "projects"),
-        fetchTable(client, "cohorts", "*, cohort_members(*)", cohortFromRow, "memberCohorts"),
+        fetchTable(
+          client,
+          "cohorts",
+          includePrivate ? "*, cohort_members(*)" : `*, cohort_members(${PUBLIC_MEMBER_COLUMNS})`,
+          cohortFromRow,
+          "memberCohorts"
+        ),
       ]);
 
     for (const [key, value] of Object.entries(json)) {
diff --git a/supabase/migrations/0008_member_email_privacy.sql b/supabase/migrations/0008_member_email_privacy.sql
new file mode 100644
index 0000000..f3e2ea7
--- /dev/null
+++ b/supabase/migrations/0008_member_email_privacy.sql
@@ -0,0 +1,12 @@
+-- 0008 — Hide member emails from the public API.
+--
+-- APPLY ONLY AFTER the app version that selects explicit cohort_members
+-- columns is live. The old code selects cohort_members(*), which fails once
+-- anon loses the email column, and the whole site falls back to defaults.
+--
+-- anon can still read every other column; staff read email through the
+-- authenticated role and the staff policy.
+
+revoke select on public.cohort_members from anon;
+grant select (id, cohort_id, name, role, dept, image, linkedin, sort_order)
+  on public.cohort_members to anon;
-- 
2.43.0


From 933cd91cc1ae1c6f080e52aebb646d08ac020066 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 05/19] build: add Vitest, ESLint and pg; patch next and sharp
 advisories

Co-authored-by: Claude <noreply@anthropic.com>
---
 eslint.config.mjs           |  18 +++++
 package.json                |  15 +++-
 tests/db/rls.test.js        | 137 ++++++++++++++++++++++++++++++++++++
 tests/unit/content.test.js  |  33 +++++++++
 tests/unit/fake-supabase.js |  73 +++++++++++++++++++
 vitest.config.mjs           |  12 ++++
 vitest.smoke.config.mjs     |   5 ++
 7 files changed, 291 insertions(+), 2 deletions(-)
 create mode 100644 eslint.config.mjs
 create mode 100644 tests/db/rls.test.js
 create mode 100644 tests/unit/content.test.js
 create mode 100644 tests/unit/fake-supabase.js
 create mode 100644 vitest.config.mjs
 create mode 100644 vitest.smoke.config.mjs

diff --git a/eslint.config.mjs b/eslint.config.mjs
new file mode 100644
index 0000000..dd0990b
--- /dev/null
+++ b/eslint.config.mjs
@@ -0,0 +1,18 @@
+import { dirname } from "node:path";
+import { fileURLToPath } from "node:url";
+import { FlatCompat } from "@eslint/eslintrc";
+
+const compat = new FlatCompat({ baseDirectory: dirname(fileURLToPath(import.meta.url)) });
+
+const config = [
+  { ignores: [".next/**", "node_modules/**", "public/**", "coverage/**"] },
+  ...compat.extends("next/core-web-vitals"),
+  {
+    rules: {
+      "react/no-unescaped-entities": "off",
+      "@next/next/no-img-element": "off",
+    },
+  },
+];
+
+export default config;
diff --git a/package.json b/package.json
index 6c6f26c..62f8e0a 100644
--- a/package.json
+++ b/package.json
@@ -7,7 +7,13 @@
     "dev": "next dev",
     "build": "next build",
     "start": "next start",
-    "seed": "node supabase/seed.mjs"
+    "seed": "node supabase/seed.mjs",
+    "lint": "eslint .",
+    "test": "vitest run",
+    "test:unit": "vitest run tests/unit",
+    "test:db": "vitest run tests/db",
+    "test:smoke": "vitest run --config vitest.smoke.config.mjs",
+    "vercel-build": "npm run lint && npm run test:unit && next build"
   },
   "dependencies": {
     "@gsap/react": "^2.1.2",
@@ -27,9 +33,14 @@
     "three": "^0.186.0"
   },
   "devDependencies": {
+    "@eslint/eslintrc": "^3.3.7",
     "@tailwindcss/postcss": "^4.3.3",
     "dotenv": "^17.2.2",
+    "eslint": "^9.39.5",
+    "eslint-config-next": "^15.1.6",
+    "pg": "^8.23.1",
     "shadcn": "^4.21.1",
-    "tailwindcss": "^4.3.3"
+    "tailwindcss": "^4.3.3",
+    "vitest": "^3.2.7"
   }
 }
diff --git a/tests/db/rls.test.js b/tests/db/rls.test.js
new file mode 100644
index 0000000..897cb0a
--- /dev/null
+++ b/tests/db/rls.test.js
@@ -0,0 +1,137 @@
+// Row Level Security tests against real Postgres with the repo's migrations.
+// Skipped unless TEST_DATABASE_URL points at a Postgres you can drop/create on.
+import { afterAll, beforeAll, describe, expect, it } from "vitest";
+import { as, buildDatabase, IDS } from "./setup.mjs";
+
+const URL = process.env.TEST_DATABASE_URL;
+const suite = URL ? describe : describe.skip;
+
+suite("database security (RLS)", () => {
+  let db;
+  beforeAll(async () => {
+    db = await buildDatabase(URL);
+  }, 60_000);
+  afterAll(async () => {
+    await db?.end();
+  });
+
+  const anon = (sql, p) => as(db, "anon", null, sql, p);
+  const user = (id) => (sql, p) => as(db, "authenticated", id, sql, p);
+
+  describe("sign-up cannot grant itself access", () => {
+    it("a self-signup asking for admin becomes an inactive editor", async () => {
+      const { rows } = await db.query("select role, is_active from public.profiles where id = $1", [IDS.outsider]);
+      expect(rows[0]).toEqual({ role: "editor", is_active: false });
+    });
+
+    it("accounts the server creates as staff are active with the requested role", async () => {
+      const { rows } = await db.query("select role, is_active from public.profiles where id = $1", [IDS.admin]);
+      expect(rows[0]).toEqual({ role: "admin", is_active: true });
+    });
+
+    it("new profiles default to inactive", async () => {
+      const { rows } = await db.query(
+        "select column_default from information_schema.columns where table_schema = 'public' and table_name = 'profiles' and column_name = 'is_active'"
+      );
+      expect(rows[0].column_default).toBe("false");
+    });
+  });
+
+  describe("anonymous visitors", () => {
+    it("see only published rows", async () => {
+      for (const table of ["announcements", "projects"]) {
+        const { rows } = await anon(`select slug from public.${table}`);
+        expect(rows.every((r) => !["draft", "hidden"].includes(r.slug))).toBe(true);
+        expect(rows.length).toBe(1);
+      }
+      const parts = await anon("select slug from public.project_parts");
+      expect(parts.rows.map((r) => r.slug)).toEqual(["part-pub"]);
+    });
+
+    it("cannot read contact messages, profiles or the media table", async () => {
+      for (const table of ["contact_messages", "profiles", "media"]) {
+        const { rows, error } = await anon(`select * from public.${table}`);
+        expect(error ?? rows.length).toSatisfy((v) => v === 0 || typeof v === "string");
+      }
+    });
+
+    it("cannot read member emails, but can read the rest of the member row", async () => {
+      expect((await anon("select email from public.cohort_members")).error).toMatch(/permission denied/);
+      const { rows } = await anon("select id, name, role, dept, image, linkedin, sort_order from public.cohort_members");
+      expect(rows[0].name).toBe("Member");
+    });
+
+    it("cannot write to any table", async () => {
+      expect((await anon("insert into public.announcements (slug, title) values ('x', 'x')")).error).toBeTruthy();
+      expect((await anon("insert into public.contact_messages (name, email, message) values ('x','x@x.io','x')")).error).toBeTruthy();
+      expect((await anon("update public.announcements set title = 'pwned'")).count).toBe(0);
+      expect((await anon("delete from public.announcements")).count).toBe(0);
+      expect((await anon("update public.sections set value = '{}'")).count).toBe(0);
+    });
+
+    it("cannot list storage objects (public URLs do not need this)", async () => {
+      expect((await anon("select name from storage.objects")).rows).toEqual([]);
+    });
+
+    it("cannot call security-definer helpers over the API", async () => {
+      const { rows } = await db.query(`
+        select p.proname
+          from pg_proc p join pg_namespace n on n.oid = p.pronamespace
+         where n.nspname = 'public' and p.prosecdef
+           and (has_function_privilege('anon', p.oid, 'execute')
+             or has_function_privilege('authenticated', p.oid, 'execute'))`);
+      expect(rows).toEqual([]);
+    });
+  });
+
+  describe("signed-in accounts that are not staff", () => {
+    const outsider = user(IDS.outsider);
+    const suspended = user(IDS.suspended);
+
+    it("see their own profile only", async () => {
+      const { rows } = await outsider("select id from public.profiles");
+      expect(rows.map((r) => r.id)).toEqual([IDS.outsider]);
+    });
+
+    it("cannot promote themselves", async () => {
+      expect((await outsider("update public.profiles set role = 'admin', is_active = true where id = $1", [IDS.outsider])).count).toBe(0);
+    });
+
+    it("cannot read messages, members or drafts, or write content", async () => {
+      for (const who of [outsider, suspended]) {
+        expect((await who("select * from public.contact_messages")).rows).toEqual([]);
+        expect((await who("select * from public.cohort_members")).rows).toEqual([]);
+        expect((await who("select * from public.announcements where not published")).rows).toEqual([]);
+        expect((await who("insert into public.announcements (slug, title) values ('x', 'x')")).error).toBeTruthy();
+        expect((await who("select name from storage.objects")).rows).toEqual([]);
+      }
+    });
+  });
+
+  describe("staff", () => {
+    const editor = user(IDS.editor);
+    const admin = user(IDS.admin);
+
+    it("editors manage content and read messages and drafts", async () => {
+      expect((await editor("select * from public.contact_messages")).rows.length).toBe(1);
+      expect((await editor("select * from public.announcements")).rows.length).toBe(2);
+      expect((await editor("select email from public.cohort_members")).rows[0].email).toBe("member@example.com");
+      expect((await editor("insert into public.announcements (slug, title) values ('new', 'New')")).count).toBe(1);
+      expect((await editor("select name from storage.objects")).rows.length).toBe(1);
+    });
+
+    it("editors cannot change accounts", async () => {
+      expect((await editor("update public.profiles set role = 'admin' where id = $1", [IDS.editor])).count).toBe(0);
+      expect((await editor("update public.profiles set is_active = true where id = $1", [IDS.outsider])).count).toBe(0);
+    });
+
+    it("admins can activate and change accounts", async () => {
+      expect((await admin("update public.profiles set is_active = true where id = $1", [IDS.outsider])).count).toBe(1);
+    });
+  });
+
+  it("media bucket does not accept SVG", async () => {
+    const { rows } = await db.query("select allowed_mime_types from storage.buckets where id = 'media'");
+    if (rows[0]?.allowed_mime_types) expect(rows[0].allowed_mime_types).not.toContain("image/svg+xml");
+  });
+});
diff --git a/tests/unit/content.test.js b/tests/unit/content.test.js
new file mode 100644
index 0000000..07902a6
--- /dev/null
+++ b/tests/unit/content.test.js
@@ -0,0 +1,33 @@
+import { describe, expect, it } from "vitest";
+import { getContent, PUBLIC_MEMBER_COLUMNS, readContent } from "@/lib/content";
+import { fakeSupabase } from "./fake-supabase";
+
+const memberQuery = (client) => client.calls.find((c) => c.table === "cohorts").columns;
+
+describe("member emails never reach the public site", () => {
+  it("the public read asks the database for explicit member columns, without email", async () => {
+    const client = fakeSupabase();
+    await readContent(client);
+    expect(memberQuery(client)).toBe(`*, cohort_members(${PUBLIC_MEMBER_COLUMNS})`);
+    expect(PUBLIC_MEMBER_COLUMNS).not.toMatch(/email/);
+  });
+
+  it("only the admin read selects every member column", async () => {
+    const client = fakeSupabase();
+    await readContent(client, { includePrivate: true });
+    expect(memberQuery(client)).toBe("*, cohort_members(*)");
+  });
+
+  it("getContent strips emails even from bundled defaults", async () => {
+    const { memberCohorts } = await getContent();
+    for (const cohort of memberCohorts) {
+      for (const member of cohort.members) expect(member).not.toHaveProperty("email");
+    }
+  });
+
+  it("falls back to bundled content when the database errors", async () => {
+    const client = fakeSupabase({}, { failOn: { "announcements.select": "boom" } });
+    const content = await readContent(client);
+    expect(content.announcements.length).toBeGreaterThan(0);
+  });
+});
diff --git a/tests/unit/fake-supabase.js b/tests/unit/fake-supabase.js
new file mode 100644
index 0000000..ef856fb
--- /dev/null
+++ b/tests/unit/fake-supabase.js
@@ -0,0 +1,73 @@
+// In-memory stand-in for the supabase-js query builder: just the calls our
+// server code makes. failOn: { "table.op": "message" } makes that call fail.
+export function fakeSupabase(initial = {}, { failOn = {}, cascade = {} } = {}) {
+  const db = structuredClone(initial);
+  const calls = [];
+  let nextId = 1;
+
+  function from(table) {
+    db[table] ??= [];
+    const state = { op: "select", filters: [], payload: null, returning: false, head: false, columns: "*" };
+    const matches = (r) => state.filters.every((f) => f(r));
+
+    async function run() {
+      calls.push({ table, op: state.op, columns: state.columns });
+      const failure = failOn[`${table}.${state.op}`];
+      if (failure) return { data: null, error: { message: failure } };
+
+      if (state.op === "select") {
+        const rows = db[table].filter(matches);
+        return state.head ? { data: null, count: rows.length, error: null } : { data: structuredClone(rows), error: null };
+      }
+      if (state.op === "delete") {
+        const gone = db[table].filter(matches);
+        db[table] = db[table].filter((r) => !matches(r));
+        for (const [child, fk] of cascade[table] ?? []) {
+          const ids = new Set(gone.map((r) => r.id));
+          db[child] = (db[child] ?? []).filter((r) => !ids.has(r[fk]));
+        }
+        return { data: null, error: null };
+      }
+      if (state.op === "upsert") {
+        for (const row of state.payload) {
+          const i = db[table].findIndex((r) => r.id === row.id);
+          if (i >= 0) db[table][i] = { ...db[table][i], ...row };
+          else db[table].push({ ...row, id: row.id ?? `gen-${nextId++}` });
+        }
+        return { data: null, error: null };
+      }
+      const inserted = state.payload.map((row) => ({ created_at: new Date().toISOString(), ...row, id: `gen-${nextId++}` }));
+      db[table].push(...inserted);
+      return { data: state.returning ? structuredClone(inserted) : null, error: null };
+    }
+
+    const q = {
+      select(columns = "*", opts = {}) {
+        if (state.op === "insert") state.returning = true;
+        else {
+          state.columns = columns;
+          state.head = Boolean(opts.head);
+        }
+        return q;
+      },
+      delete() { state.op = "delete"; return q; },
+      upsert(rows) { state.op = "upsert"; state.payload = [].concat(rows); return q; },
+      insert(rows) { state.op = "insert"; state.payload = [].concat(rows); return q; },
+      eq(c, v) { state.filters.push((r) => r[c] === v); return q; },
+      neq(c, v) { state.filters.push((r) => r[c] !== v); return q; },
+      gte(c, v) { state.filters.push((r) => String(r[c] ?? "") >= String(v)); return q; },
+      in(c, vs) { state.filters.push((r) => vs.includes(r[c])); return q; },
+      not(c, _op, list) {
+        const vs = list.replace(/[()]/g, "").split(",").filter(Boolean);
+        state.filters.push((r) => !vs.includes(r[c]));
+        return q;
+      },
+      order() { return q; },
+      single() { return q; },
+      then(resolve, reject) { return run().then(resolve, reject); },
+    };
+    return q;
+  }
+
+  return { from, tables: () => db, calls };
+}
diff --git a/vitest.config.mjs b/vitest.config.mjs
new file mode 100644
index 0000000..65b1f93
--- /dev/null
+++ b/vitest.config.mjs
@@ -0,0 +1,12 @@
+import { fileURLToPath } from "node:url";
+import { defineConfig } from "vitest/config";
+
+export default defineConfig({
+  resolve: { alias: { "@": fileURLToPath(new URL("./", import.meta.url)) } },
+  test: {
+    include: ["tests/**/*.test.{js,mjs}", "lib/**/*.test.{js,mjs}"],
+    exclude: ["tests/smoke/**", "node_modules/**"],
+    environment: "node",
+    testTimeout: 20_000,
+  },
+});
diff --git a/vitest.smoke.config.mjs b/vitest.smoke.config.mjs
new file mode 100644
index 0000000..70a3a8e
--- /dev/null
+++ b/vitest.smoke.config.mjs
@@ -0,0 +1,5 @@
+import { defineConfig } from "vitest/config";
+
+export default defineConfig({
+  test: { include: ["tests/smoke/**/*.test.mjs"], environment: "node", testTimeout: 30_000, retry: 0 },
+});
-- 
2.43.0


From 2dfa3862af932dd9996491b09d4e179b4a060b8b Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 06/19] fix(admin): restore deleted rows when a save fails
 halfway

Co-authored-by: Claude <noreply@anthropic.com>
---
 app/admin/actions.js             | 63 +++++++++++++++++++---
 tests/unit/admin-actions.test.js | 91 ++++++++++++++++++++++++++++++++
 2 files changed, 146 insertions(+), 8 deletions(-)
 create mode 100644 tests/unit/admin-actions.test.js

diff --git a/app/admin/actions.js b/app/admin/actions.js
index 0ac3127..157a1c4 100644
--- a/app/admin/actions.js
+++ b/app/admin/actions.js
@@ -57,6 +57,22 @@ const firstRepeat = (values) => {
 
 const withoutId = ({ id, ...rest }) => rest;
 
+// Saving a collection is several requests (delete, update, insert). There is no
+// transaction across them, so take a copy of every row we are about to delete
+// and put it back if a later step fails. A failed save then leaves the old
+// content in place instead of silently losing rows.
+async function snapshot(query, what) {
+  const { data, error } = await query;
+  fail(error, `Could not read ${what} before saving`);
+  return data ?? [];
+}
+
+async function restore(supabase, table, rows) {
+  if (!rows.length) return;
+  const { error } = await supabase.from(table).upsert(rows);
+  if (error) console.error(`[content] could not restore ${table} after a failed save:`, error.message);
+}
+
 const MISSING_COLUMN = /Could not find the '([^']+)' column/i;
 
 async function writeRows(run, rows, table) {
@@ -104,12 +120,30 @@ async function replaceCollection(supabase, key, items) {
     }
   }
 
-  let del = supabase.from(cfg.table).delete();
-  del = keptIds.length
-    ? del.not("id", "in", `(${keptIds.join(",")})`)
-    : del.neq("id", EVERY_ROW);
-  fail((await del).error, `Could not remove deleted ${key}`);
+  const removedScope = (query) =>
+    keptIds.length ? query.not("id", "in", `(${keptIds.join(",")})`) : query.neq("id", EVERY_ROW);
+
+  const removed = await snapshot(removedScope(supabase.from(cfg.table).select("*")), key);
+  const removedChildren =
+    cfg.child && removed.length
+      ? await snapshot(
+          supabase.from(cfg.child.table).select("*").in(cfg.child.fk, removed.map((r) => r.id)),
+          cfg.child.key
+        )
+      : [];
+
+  fail((await removedScope(supabase.from(cfg.table).delete())).error, `Could not remove deleted ${key}`);
+
+  try {
+    await writeCollection(supabase, cfg, key, list, rows, existing, fresh);
+  } catch (error) {
+    await restore(supabase, cfg.table, removed);
+    if (cfg.child) await restore(supabase, cfg.child.table, removedChildren);
+    throw error;
+  }
+}
 
+async function writeCollection(supabase, cfg, key, list, rows, existing, fresh) {
   if (existing.length) {
     const { error } = await writeRows(
       (batch) => supabase.from(cfg.table).upsert(batch),
@@ -160,10 +194,23 @@ async function replaceChildren(supabase, cfg, list, rows, inserted) {
     );
   }
 
-  let del = supabase.from(child.table).delete().in(child.fk, parentIds);
-  if (keptIds.length) del = del.not("id", "in", `(${keptIds.join(",")})`);
-  fail((await del).error, `Could not remove deleted ${child.key}`);
+  const childScope = (query) => {
+    const scoped = query.in(child.fk, parentIds);
+    return keptIds.length ? scoped.not("id", "in", `(${keptIds.join(",")})`) : scoped;
+  };
+
+  const removed = await snapshot(childScope(supabase.from(child.table).select("*")), child.key);
+  fail((await childScope(supabase.from(child.table).delete())).error, `Could not remove deleted ${child.key}`);
+
+  try {
+    await writeChildren(supabase, child, childRows);
+  } catch (error) {
+    await restore(supabase, child.table, removed);
+    throw error;
+  }
+}
 
+async function writeChildren(supabase, child, childRows) {
   const update = childRows.filter((r) => r.id);
   const create = childRows.filter((r) => !r.id).map(withoutId);
 
diff --git a/tests/unit/admin-actions.test.js b/tests/unit/admin-actions.test.js
new file mode 100644
index 0000000..11d9b09
--- /dev/null
+++ b/tests/unit/admin-actions.test.js
@@ -0,0 +1,91 @@
+import { beforeEach, describe, expect, it, vi } from "vitest";
+import { cohortFromRow } from "@/lib/mappers";
+import { fakeSupabase } from "./fake-supabase";
+
+let client;
+let staff;
+const createUserSpy = vi.fn(async () => ({ error: null }));
+
+vi.mock("server-only", () => ({}));
+vi.mock("next/cache", () => ({ revalidatePath: vi.fn() }));
+vi.mock("@/lib/content", () => ({ readContent: vi.fn(async () => ({})) }));
+vi.mock("@/lib/supabase/server", () => ({
+  createClient: async () => client,
+  getStaff: async () => staff,
+}));
+vi.mock("@/lib/supabase/admin", () => ({
+  createAdminClient: () => ({ auth: { admin: { createUser: createUserSpy } } }),
+}));
+
+const { createUser, saveSection } = await import("@/app/admin/actions");
+
+const announcement = (id, slug) => ({ id, slug, title: slug, body: "", tag: "Update", date_label: "", pinned: false, published: true, sort_order: 0 });
+
+describe("saving a collection never silently loses rows", () => {
+  beforeEach(() => {
+    staff = { id: "s1", role: "admin", is_active: true };
+  });
+
+  it("puts deleted rows back when a later step fails", async () => {
+    client = fakeSupabase(
+      { announcements: [announcement("a1", "keep"), announcement("a2", "old")] },
+      { failOn: { "announcements.insert": "network error" } }
+    );
+    const items = [
+      { _id: "a1", id: "keep", title: "Keep" },
+      { id: "brand-new", title: "New" },
+    ];
+    await expect(saveSection("announcements", items)).rejects.toThrow(/network error/);
+    expect(client.tables().announcements.map((r) => r.id).sort()).toEqual(["a1", "a2"]);
+  });
+
+  it("restores a removed cohort together with its members", async () => {
+    const cohorts = [
+      { id: "c1", year: "2025", sort_order: 0 },
+      { id: "c2", year: "2026", sort_order: 1 },
+    ];
+    const members = [
+      { id: "m1", cohort_id: "c1", name: "Old", role: "", dept: "", image: "", linkedin: "", email: "old@example.com", sort_order: 0 },
+      { id: "m2", cohort_id: "c2", name: "New", role: "", dept: "", image: "", linkedin: "", email: "", sort_order: 0 },
+    ];
+    client = fakeSupabase(
+      { cohorts, cohort_members: members },
+      { failOn: { "cohort_members.insert": "timeout" }, cascade: { cohorts: [["cohort_members", "cohort_id"]] } }
+    );
+    const keep = cohortFromRow({ ...cohorts[1], cohort_members: [members[1]] });
+    keep.members.push({ name: "Joiner", role: "", dept: "", image: "", linkedin: "", email: "" });
+
+    await expect(saveSection("memberCohorts", [keep])).rejects.toThrow(/timeout/);
+    expect(client.tables().cohorts.map((r) => r.id).sort()).toEqual(["c1", "c2"]);
+    expect(client.tables().cohort_members.find((m) => m.id === "m1")?.email).toBe("old@example.com");
+  });
+
+  it("a successful save removes exactly the deleted rows", async () => {
+    client = fakeSupabase({ announcements: [announcement("a1", "keep"), announcement("a2", "old")] });
+    await saveSection("announcements", [{ _id: "a1", id: "keep", title: "Keep" }]);
+    expect(client.tables().announcements.map((r) => r.id)).toEqual(["a1"]);
+  });
+
+  it("refuses to save without a staff session", async () => {
+    staff = null;
+    client = fakeSupabase({ announcements: [announcement("a1", "keep")] });
+    await expect(saveSection("announcements", [])).rejects.toThrow(/session/);
+    expect(client.tables().announcements).toHaveLength(1);
+  });
+});
+
+describe("account creation", () => {
+  it("marks staff in app_metadata (server-only), never in user_metadata", async () => {
+    staff = { id: "s1", role: "admin", is_active: true };
+    client = fakeSupabase({ profiles: [] });
+    await createUser({ name: "Riya", email: "riya@example.com", password: "long-enough-1", role: "editor" });
+    const args = createUserSpy.mock.calls.at(-1)[0];
+    expect(args.app_metadata).toEqual({ staff: true, role: "editor" });
+    expect(args.user_metadata).not.toHaveProperty("role");
+  });
+
+  it("only admins can create accounts", async () => {
+    staff = { id: "s2", role: "editor", is_active: true };
+    await expect(createUser({ name: "x", email: "x@example.com", password: "long-enough-1", role: "admin" })).rejects.toThrow(/admin/);
+  });
+});
-- 
2.43.0


From 15e71977a812e90f06f63271ccef0030ac2554d6 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 07/19] feat(security): add security headers and report-only
 CSP; lint during builds

Co-authored-by: Claude <noreply@anthropic.com>
---
 lib/security-headers.mjs            | 52 +++++++++++++++++++++++++++++
 next.config.mjs                     |  8 ++++-
 tests/unit/security-headers.test.js | 29 ++++++++++++++++
 3 files changed, 88 insertions(+), 1 deletion(-)
 create mode 100644 lib/security-headers.mjs
 create mode 100644 tests/unit/security-headers.test.js

diff --git a/lib/security-headers.mjs b/lib/security-headers.mjs
new file mode 100644
index 0000000..e148507
--- /dev/null
+++ b/lib/security-headers.mjs
@@ -0,0 +1,52 @@
+// Security headers for every response. Kept out of next.config.mjs so tests
+// can check them.
+//
+// The full Content-Security-Policy ships as Report-Only first: watch the
+// browser console on a preview deploy, fix anything it reports, then move it
+// to the enforced header. The enforced header already blocks framing
+// (clickjacking on the admin panel), plugins, <base> hijacking and forms
+// posting to other sites.
+
+function supabaseOrigin() {
+  try {
+    return new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).origin;
+  } catch {
+    return "";
+  }
+}
+
+export function contentSecurityPolicy({ dev = process.env.NODE_ENV !== "production" } = {}) {
+  const supabase = supabaseOrigin();
+  const realtime = supabase.replace(/^https:/, "wss:");
+  return [
+    "default-src 'self'",
+    `script-src 'self' 'unsafe-inline'${dev ? " 'unsafe-eval'" : ""}`,
+    "style-src 'self' 'unsafe-inline'",
+    `img-src 'self' data: blob: ${supabase}`.trim(),
+    `media-src 'self' blob: ${supabase}`.trim(),
+    "font-src 'self' data:",
+    `connect-src 'self' ${supabase} ${realtime}`.trim(),
+    "worker-src 'self' blob:",
+    "frame-src 'self' https://www.youtube-nocookie.com https://www.youtube.com",
+    "object-src 'none'",
+    "base-uri 'self'",
+    "form-action 'self'",
+    "frame-ancestors 'none'",
+    "upgrade-insecure-requests",
+  ].join("; ");
+}
+
+export const ENFORCED_CSP = "frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'";
+
+export function securityHeaders() {
+  return [
+    { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
+    { key: "X-Content-Type-Options", value: "nosniff" },
+    { key: "X-Frame-Options", value: "DENY" },
+    { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
+    { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=(), usb=()" },
+    { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
+    { key: "Content-Security-Policy", value: ENFORCED_CSP },
+    { key: "Content-Security-Policy-Report-Only", value: contentSecurityPolicy() },
+  ];
+}
diff --git a/next.config.mjs b/next.config.mjs
index 717f7aa..3cb6293 100644
--- a/next.config.mjs
+++ b/next.config.mjs
@@ -1,3 +1,5 @@
+import { securityHeaders } from "./lib/security-headers.mjs";
+
 function supabasePattern() {
   try {
     const { protocol, hostname } = new URL(process.env.NEXT_PUBLIC_SUPABASE_URL);
@@ -17,7 +19,11 @@ const nextConfig = {
 
   transpilePackages: ["three"],
 
-  eslint: { ignoreDuringBuilds: true },
+  poweredByHeader: false,
+
+  async headers() {
+    return [{ source: "/(.*)", headers: securityHeaders() }];
+  },
 };
 
 export default nextConfig;
diff --git a/tests/unit/security-headers.test.js b/tests/unit/security-headers.test.js
new file mode 100644
index 0000000..c101b60
--- /dev/null
+++ b/tests/unit/security-headers.test.js
@@ -0,0 +1,29 @@
+import { describe, expect, it } from "vitest";
+import { contentSecurityPolicy, securityHeaders } from "@/lib/security-headers.mjs";
+import nextConfig from "@/next.config.mjs";
+
+const byKey = (list) => Object.fromEntries(list.map((h) => [h.key, h.value]));
+
+describe("security headers", () => {
+  it("apply to every route", async () => {
+    const [rule] = await nextConfig.headers();
+    expect(rule.source).toBe("/(.*)");
+    expect(byKey(rule.headers)["X-Content-Type-Options"]).toBe("nosniff");
+  });
+
+  it("block framing, sniffing and plugin content", () => {
+    const h = byKey(securityHeaders());
+    expect(h["Content-Security-Policy"]).toContain("frame-ancestors 'none'");
+    expect(h["Content-Security-Policy"]).toContain("object-src 'none'");
+    expect(h["X-Frame-Options"]).toBe("DENY");
+    expect(h["Strict-Transport-Security"]).toMatch(/max-age=\d{8}/);
+  });
+
+  it("never allow eval in production", () => {
+    expect(contentSecurityPolicy({ dev: false })).not.toContain("unsafe-eval");
+  });
+
+  it("lint runs during builds", () => {
+    expect(nextConfig.eslint?.ignoreDuringBuilds).not.toBe(true);
+  });
+});
-- 
2.43.0


From 20f15dac555d3aa0de5d06996cf3e5beeddcfcfe Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 08/19] perf(middleware): refresh Supabase sessions only on the
 admin path

Co-authored-by: Claude <noreply@anthropic.com>
---
 middleware.js | 10 +++++++++-
 1 file changed, 9 insertions(+), 1 deletion(-)

diff --git a/middleware.js b/middleware.js
index b618142..e9b0957 100644
--- a/middleware.js
+++ b/middleware.js
@@ -17,9 +17,17 @@ export async function middleware(request) {
       rewritten.pathname = pathname.replace(`/${ADMIN_PATH}`, `/${REAL}`);
       return withSession(request, NextResponse.rewrite(rewritten));
     }
+
+    return NextResponse.next();
   }
 
-  return withSession(request, NextResponse.next({ request }));
+  // Only the admin area needs a Supabase session. Public pages are cached and
+  // read as anon, so skip the auth round-trip on every visitor's request.
+  const isAdmin = pathname === `/${REAL}` || pathname.startsWith(`/${REAL}/`);
+  if (ADMIN_PATH === REAL && isAdmin) {
+    return withSession(request, NextResponse.next({ request }));
+  }
+  return NextResponse.next();
 }
 
 async function withSession(request, response) {
-- 
2.43.0


From 05474f9b8f6afb87812ecd505d1dad5c21f1476a Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 09/19] test(contact): cover honeypot, validation, length caps
 and rate limit

Co-authored-by: Claude <noreply@anthropic.com>
---
 tests/unit/send-message.test.js | 62 +++++++++++++++++++++++++++++++++
 1 file changed, 62 insertions(+)
 create mode 100644 tests/unit/send-message.test.js

diff --git a/tests/unit/send-message.test.js b/tests/unit/send-message.test.js
new file mode 100644
index 0000000..e765f73
--- /dev/null
+++ b/tests/unit/send-message.test.js
@@ -0,0 +1,62 @@
+import { beforeEach, describe, expect, it, vi } from "vitest";
+import { fakeSupabase } from "./fake-supabase";
+
+let client;
+vi.mock("server-only", () => ({}));
+vi.mock("@/lib/supabase/admin", () => ({ createAdminClient: () => client }));
+
+const { sendMessage } = await import("@/lib/send-message");
+
+const form = (fields) => {
+  const data = new FormData();
+  for (const [k, v] of Object.entries({ name: "Asha", email: "asha@example.com", subject: "Hi", message: "Hello", ...fields })) data.set(k, v);
+  return data;
+};
+const stored = () => client.tables().contact_messages ?? [];
+
+describe("contact form", () => {
+  beforeEach(() => {
+    client = fakeSupabase({ contact_messages: [] });
+  });
+
+  it("stores a valid message", async () => {
+    expect(await sendMessage(form())).toEqual({ ok: true });
+    expect(stored()).toHaveLength(1);
+  });
+
+  it("pretends to accept bot submissions but stores nothing", async () => {
+    expect(await sendMessage(form({ website: "http://spam.example" }))).toEqual({ ok: true });
+    expect(stored()).toHaveLength(0);
+  });
+
+  it("rejects a bad email and an empty message", async () => {
+    expect((await sendMessage(form({ email: "not-an-email" }))).ok).toBe(false);
+    expect((await sendMessage(form({ message: "   " }))).ok).toBe(false);
+    expect(stored()).toHaveLength(0);
+  });
+
+  it("caps field lengths", async () => {
+    await sendMessage(form({ name: "n".repeat(500), message: "m".repeat(9000) }));
+    expect(stored()[0].name).toHaveLength(120);
+    expect(stored()[0].message).toHaveLength(4000);
+  });
+
+  it("rate-limits one sender to 3 messages per 10 minutes", async () => {
+    for (let i = 0; i < 3; i++) expect((await sendMessage(form())).ok).toBe(true);
+    const fourth = await sendMessage(form());
+    expect(fourth.ok).toBe(false);
+    expect(stored()).toHaveLength(3);
+  });
+
+  it("shows a friendly error when the server key is missing", async () => {
+    client = null;
+    vi.doMock("@/lib/supabase/admin", () => ({
+      createAdminClient: () => {
+        throw new Error("SUPABASE_SERVICE_ROLE_KEY is not set");
+      },
+    }));
+    vi.resetModules();
+    const { sendMessage: send } = await import("@/lib/send-message");
+    expect((await send(form())).ok).toBe(false);
+  });
+});
-- 
2.43.0


From 7c279dfd0c6aafcf2111c0db08f084fd5fbf2f60 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 10/19] feat: add error boundaries and robots.txt

Co-authored-by: Claude <noreply@anthropic.com>
---
 app/error.jsx        | 25 +++++++++++++++++++++++++
 app/global-error.jsx | 19 +++++++++++++++++++
 app/robots.js        | 11 +++++++++++
 3 files changed, 55 insertions(+)
 create mode 100644 app/error.jsx
 create mode 100644 app/global-error.jsx
 create mode 100644 app/robots.js

diff --git a/app/error.jsx b/app/error.jsx
new file mode 100644
index 0000000..2edb75d
--- /dev/null
+++ b/app/error.jsx
@@ -0,0 +1,25 @@
+"use client";
+
+import { useEffect } from "react";
+
+export default function Error({ error, reset }) {
+  useEffect(() => {
+    console.error(error);
+  }, [error]);
+
+  return (
+    <main className="min-h-[70vh] flex flex-col items-center justify-center gap-4 px-6 text-center">
+      <p className="font-mono text-xs uppercase tracking-[0.22em] text-ink/40">Something went wrong</p>
+      <h1 className="text-2xl font-semibold text-ink">This page hit turbulence.</h1>
+      <p className="text-ink/60 max-w-md">Try again, or head back to the home page.</p>
+      <div className="flex gap-3">
+        <button type="button" onClick={() => reset()} className="rounded-full border border-ink/20 px-5 py-2 text-sm text-ink hover:border-ink/50">
+          Try again
+        </button>
+        <a href="/" className="rounded-full border border-ink/20 px-5 py-2 text-sm text-ink hover:border-ink/50">
+          Home
+        </a>
+      </div>
+    </main>
+  );
+}
diff --git a/app/global-error.jsx b/app/global-error.jsx
new file mode 100644
index 0000000..2ebd888
--- /dev/null
+++ b/app/global-error.jsx
@@ -0,0 +1,19 @@
+"use client";
+
+// Last-resort boundary for errors in the root layout itself. It replaces the
+// whole document, so it can't rely on the site's fonts or CSS.
+export default function GlobalError({ reset }) {
+  return (
+    <html lang="en">
+      <body style={{ margin: 0, minHeight: "100vh", display: "grid", placeItems: "center", background: "#06060c", color: "#e8e8f0", fontFamily: "system-ui, sans-serif", textAlign: "center" }}>
+        <div>
+          <h1 style={{ fontSize: 22 }}>Stratosphere is having trouble loading.</h1>
+          <p style={{ opacity: 0.7 }}>Please try again in a moment.</p>
+          <button type="button" onClick={() => reset()} style={{ marginTop: 12, padding: "8px 18px", borderRadius: 999, border: "1px solid #444", background: "transparent", color: "inherit", cursor: "pointer" }}>
+            Try again
+          </button>
+        </div>
+      </body>
+    </html>
+  );
+}
diff --git a/app/robots.js b/app/robots.js
new file mode 100644
index 0000000..71999b5
--- /dev/null
+++ b/app/robots.js
@@ -0,0 +1,11 @@
+import { SITE_URL } from "@/lib/site-url";
+
+// The admin path is deliberately not listed here: robots.txt is public, so
+// naming it would advertise it. The admin layout already sends noindex.
+export default function robots() {
+  return {
+    rules: [{ userAgent: "*", allow: "/" }],
+    sitemap: `${SITE_URL}/sitemap.xml`,
+    host: SITE_URL,
+  };
+}
-- 
2.43.0


From 51209b19d08dc01f3724c4c85bb7b1c5b356e7a3 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 11/19] feat(events): add-to-calendar downloads and Event
 structured data

Co-authored-by: Claude <noreply@anthropic.com>
---
 app/(site)/events/[slug]/ics/route.js | 20 ++++++
 app/(site)/events/[slug]/page.jsx     | 32 ++++++++++
 lib/event-dates.js                    | 87 +++++++++++++++++++++++++++
 tests/unit/event-dates.test.js        | 39 ++++++++++++
 4 files changed, 178 insertions(+)
 create mode 100644 app/(site)/events/[slug]/ics/route.js
 create mode 100644 lib/event-dates.js
 create mode 100644 tests/unit/event-dates.test.js

diff --git a/app/(site)/events/[slug]/ics/route.js b/app/(site)/events/[slug]/ics/route.js
new file mode 100644
index 0000000..8cda2b0
--- /dev/null
+++ b/app/(site)/events/[slug]/ics/route.js
@@ -0,0 +1,20 @@
+import { getContent } from "@/lib/content";
+import { eventIcs } from "@/lib/event-dates";
+import { SITE_URL } from "@/lib/site-url";
+
+export const revalidate = 300;
+
+export async function GET(_request, { params }) {
+  const { slug } = await params;
+  const { events } = await getContent();
+  const event = events.find((e) => e.slug === slug);
+  const ics = event && eventIcs(event, SITE_URL);
+  if (!ics) return new Response("Not found", { status: 404 });
+
+  return new Response(ics, {
+    headers: {
+      "Content-Type": "text/calendar; charset=utf-8",
+      "Content-Disposition": `attachment; filename="${slug}.ics"`,
+    },
+  });
+}
diff --git a/app/(site)/events/[slug]/page.jsx b/app/(site)/events/[slug]/page.jsx
index cceefc5..2acb9bb 100644
--- a/app/(site)/events/[slug]/page.jsx
+++ b/app/(site)/events/[slug]/page.jsx
@@ -8,6 +8,8 @@ import Cover from "@/components/Cover";
 import SplitHeading from "@/components/SplitHeading";
 import Thesis from "@/components/Thesis";
 import Label from "@/components/Label";
+import { eventSchedule } from "@/lib/event-dates";
+import { SITE_URL } from "@/lib/site-url";
 
 async function findEvent(slug) {
   const { events } = await getContent();
@@ -79,6 +81,18 @@ export default async function EventDetail({ params }) {
         {event.location && (
           <p className="font-sans text-sm text-ink/45 mt-3">{event.location}</p>
         )}
+        {upcoming && eventSchedule(event) && (
+          <a
+            href={`/events/${event.slug}/ics`}
+            className="inline-block font-sans text-sm text-aurora2 underline-offset-4 hover:underline mt-3"
+          >
+            Add to calendar
+          </a>
+        )}
+        <script
+          type="application/ld+json"
+          dangerouslySetInnerHTML={{ __html: eventJsonLd(event) }}
+        />
 
         {event.body && (
           <p className="text-ink/65 mt-5 max-w-2xl leading-relaxed">{event.body}</p>
@@ -146,3 +160,21 @@ export default async function EventDetail({ params }) {
     </main>
   );
 }
+
+function eventJsonLd(event) {
+  const schedule = eventSchedule(event);
+  const data = {
+    "@context": "https://schema.org",
+    "@type": "Event",
+    name: event.title,
+    description: event.body,
+    url: `${SITE_URL}/events/${event.slug}`,
+    eventStatus: "https://schema.org/EventScheduled",
+    eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
+    organizer: { "@type": "Organization", name: "Stratosphere — Aerospace Club, Jadavpur University", url: SITE_URL },
+    ...(schedule && { startDate: schedule.start.toISOString(), endDate: schedule.end.toISOString() }),
+    ...(event.location && { location: { "@type": "Place", name: event.location } }),
+    ...(event.image && { image: [event.image.startsWith("http") ? event.image : `${SITE_URL}${event.image}`] }),
+  };
+  return JSON.stringify(data).replace(/</g, "\\u003c");
+}
diff --git a/lib/event-dates.js b/lib/event-dates.js
new file mode 100644
index 0000000..f5a1698
--- /dev/null
+++ b/lib/event-dates.js
@@ -0,0 +1,87 @@
+// Turns the free-text date/time labels editors type ("10–11 April 2026",
+// "10:00 AM - 5:00 PM") into real dates. Returns null when a label can't be
+// read, so the site simply hides "Add to calendar" instead of guessing.
+const MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
+const IST = "+05:30";
+
+const pad = (n) => String(n).padStart(2, "0");
+
+function parseDays(label) {
+  const text = String(label ?? "").trim().toLowerCase().replace(/[–—]/g, "-").replace(/,/g, " ").replace(/\s+/g, " ");
+  const m = text.match(/^(\d{1,2})(?:\s*-\s*(\d{1,2}))?\s+([a-z]+)\s+(\d{4})$/);
+  if (!m) return null;
+  const month = MONTHS.findIndex((name) => name.startsWith(m[3].slice(0, 3)) && m[3].length >= 3);
+  if (month < 0) return null;
+  const year = Number(m[4]);
+  const first = Number(m[1]);
+  const last = m[2] ? Number(m[2]) : first;
+  if (first < 1 || last > 31 || last < first) return null;
+  return { year, month: month + 1, first, last };
+}
+
+function parseClock(text) {
+  const m = String(text).trim().toLowerCase().match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/);
+  if (!m) return null;
+  let hour = Number(m[1]);
+  const minute = Number(m[2] ?? 0);
+  if (m[3] === "pm" && hour < 12) hour += 12;
+  if (m[3] === "am" && hour === 12) hour = 0;
+  if (hour > 23 || minute > 59) return null;
+  return { hour, minute };
+}
+
+function parseTimes(label) {
+  const parts = String(label ?? "").replace(/[–—]/g, "-").split(/\s+-\s+|\s+to\s+/i);
+  if (parts.length !== 2) return null;
+  const start = parseClock(parts[0]);
+  const end = parseClock(parts[1]);
+  return start && end ? { start, end } : null;
+}
+
+const at = (y, mo, d, h, mi) => new Date(`${y}-${pad(mo)}-${pad(d)}T${pad(h)}:${pad(mi)}:00${IST}`);
+
+export function eventSchedule(event) {
+  const days = parseDays(event?.date);
+  if (!days) return null;
+  const times = parseTimes(event?.time);
+  const { year, month, first, last } = days;
+  if (times) {
+    return {
+      allDay: false,
+      start: at(year, month, first, times.start.hour, times.start.minute),
+      end: at(year, month, last, times.end.hour, times.end.minute),
+    };
+  }
+  return { allDay: true, start: at(year, month, first, 0, 0), end: at(year, month, last + 1, 0, 0), days };
+}
+
+const stamp = (date) => date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
+const escape = (text) => String(text ?? "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
+
+export function eventIcs(event, siteUrl, now = new Date()) {
+  const schedule = eventSchedule(event);
+  if (!schedule) return null;
+  const when = schedule.allDay
+    ? [
+        `DTSTART;VALUE=DATE:${schedule.days.year}${pad(schedule.days.month)}${pad(schedule.days.first)}`,
+        `DTEND;VALUE=DATE:${stamp(schedule.end).slice(0, 8)}`,
+      ]
+    : [`DTSTART:${stamp(schedule.start)}`, `DTEND:${stamp(schedule.end)}`];
+  return [
+    "BEGIN:VCALENDAR",
+    "VERSION:2.0",
+    "PRODID:-//Stratosphere JU//Events//EN",
+    "CALSCALE:GREGORIAN",
+    "BEGIN:VEVENT",
+    `UID:${event.slug}@stratosphere-ju`,
+    `DTSTAMP:${stamp(now)}`,
+    ...when,
+    `SUMMARY:${escape(event.title)}`,
+    `DESCRIPTION:${escape(`${event.body ?? ""}\n\n${siteUrl}/events/${event.slug}`)}`,
+    ...(event.location ? [`LOCATION:${escape(event.location)}`] : []),
+    `URL:${siteUrl}/events/${event.slug}`,
+    "END:VEVENT",
+    "END:VCALENDAR",
+    "",
+  ].join("\r\n");
+}
diff --git a/tests/unit/event-dates.test.js b/tests/unit/event-dates.test.js
new file mode 100644
index 0000000..9d52384
--- /dev/null
+++ b/tests/unit/event-dates.test.js
@@ -0,0 +1,39 @@
+import { describe, expect, it } from "vitest";
+import { eventIcs, eventSchedule } from "@/lib/event-dates";
+
+describe("event dates", () => {
+  it("reads a single day with a time range in IST", () => {
+    const s = eventSchedule({ date: "2 April 2026", time: "10:00 AM - 5:00 PM" });
+    expect(s.start.toISOString()).toBe("2026-04-02T04:30:00.000Z");
+    expect(s.end.toISOString()).toBe("2026-04-02T11:30:00.000Z");
+  });
+
+  it("reads a multi-day range with an en dash", () => {
+    const s = eventSchedule({ date: "10–11 April 2026", time: "10:00 AM - 5:00 PM" });
+    expect(s.end.toISOString()).toBe("2026-04-11T11:30:00.000Z");
+  });
+
+  it("falls back to an all-day event when the time is TBD", () => {
+    const s = eventSchedule({ date: "14 Nov 2026", time: "TBD" });
+    expect(s.allDay).toBe(true);
+  });
+
+  it("returns null for labels it cannot read", () => {
+    for (const date of ["TBD", "", "Spring 2026", "31-30 April 2026"]) {
+      expect(eventSchedule({ date, time: "10:00 AM - 5:00 PM" })).toBeNull();
+    }
+  });
+
+  it("builds a valid, escaped calendar file", () => {
+    const ics = eventIcs(
+      { slug: "srijan", title: "Glide, Fly; Land", body: "Bring a pen", date: "10–11 April 2026", time: "10:00 AM - 5:00 PM", location: "JU, Kolkata" },
+      "https://example.com",
+      new Date("2026-01-01T00:00:00Z")
+    );
+    expect(ics).toContain("BEGIN:VCALENDAR\r\n");
+    expect(ics).toContain("DTSTART:20260410T043000Z");
+    expect(ics).toContain("SUMMARY:Glide\\, Fly\\; Land");
+    expect(ics).toContain("LOCATION:JU\\, Kolkata");
+    expect(eventIcs({ slug: "x", title: "x", date: "TBD" }, "https://example.com")).toBeNull();
+  });
+});
-- 
2.43.0


From aaf59fb63ced4d994c5f0b5360d101d3b2b91aa4 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 12/19] feat(seo): add Organization structured data

Co-authored-by: Claude <noreply@anthropic.com>
---
 app/layout.jsx | 17 ++++++++++++++++-
 1 file changed, 16 insertions(+), 1 deletion(-)

diff --git a/app/layout.jsx b/app/layout.jsx
index a435c1b..9a34881 100644
--- a/app/layout.jsx
+++ b/app/layout.jsx
@@ -63,6 +63,20 @@ const THEME_SCRIPT = `(function () {
   document.documentElement.dataset.theme = theme;
 })();`;
 
+const ORGANIZATION_JSON_LD = JSON.stringify({
+  "@context": "https://schema.org",
+  "@type": "Organization",
+  name: "Stratosphere — Aerospace Club, Jadavpur University",
+  alternateName: "Stratosphere",
+  url: SITE_URL,
+  logo: `${SITE_URL}/icon.png`,
+  parentOrganization: { "@type": "CollegeOrUniversity", name: "Jadavpur University" },
+  sameAs: [
+    "https://www.instagram.com/aerospace_club_ju",
+    "https://www.linkedin.com/company/aerospace-club-ju/",
+  ],
+}).replace(/</g, "\\u003c");
+
 export default function RootLayout({ children }) {
   return (
     <html
@@ -73,7 +87,8 @@ export default function RootLayout({ children }) {
       <head>
         <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
       </head>
-      <body>{children}</body>
+      <body>
+        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ORGANIZATION_JSON_LD }} />{children}</body>
     </html>
   );
 }
-- 
2.43.0


From 6b341109f4554292c51f4ede6a158af26e16fc76 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 13/19] fix(copy): drop template office hours and archive
 filler; credit the site

Co-authored-by: Claude <noreply@anthropic.com>
---
 components/FeedArchive.jsx | 2 +-
 components/Footer.jsx      | 9 ++++++++-
 data.js                    | 6 +-----
 3 files changed, 10 insertions(+), 7 deletions(-)

diff --git a/components/FeedArchive.jsx b/components/FeedArchive.jsx
index 276b194..d2b3363 100644
--- a/components/FeedArchive.jsx
+++ b/components/FeedArchive.jsx
@@ -28,7 +28,7 @@ export default function FeedArchive({
         <span>
           <span className="block text-ink text-base font-semibold tracking-[-0.01em]">{label}</span>
           <span className="block text-sm text-ink/45 mt-1">
-            {count} {count === 1 ? noun : nounPlural} kept on record, oldest still readable.
+            {count} earlier {count === 1 ? noun : nounPlural}
           </span>
         </span>
 
diff --git a/components/Footer.jsx b/components/Footer.jsx
index 89471d6..c71c601 100644
--- a/components/Footer.jsx
+++ b/components/Footer.jsx
@@ -41,6 +41,7 @@ export default function Footer({ contact = {}, footerCols = [], compact = false
 
           <FooterAddressColumn address={address} email={email} always={compact} />
 
+          {hours.length > 0 && (
           <div>
             <h4 className="font-mono text-[10px] uppercase tracking-[0.22em] text-ink/35 mb-4">
               Office hours
@@ -54,6 +55,7 @@ export default function Footer({ contact = {}, footerCols = [], compact = false
               ))}
             </dl>
           </div>
+          )}
           {accounts.length > 0 && (
             <div>
               <h4 className="font-mono text-[10px] uppercase tracking-[0.22em] text-ink/35 mb-4">
@@ -87,7 +89,12 @@ export default function Footer({ contact = {}, footerCols = [], compact = false
         </div>
         
         <div className="flex flex-wrap gap-x-6 gap-y-2 justify-between pt-6 border-t border-ink/10 text-xs text-ink/40">
-          <span>Made By Aerospace Club</span>
+          <span>
+            Website by{" "}
+            <a href="https://github.com/deyaayush2006-coder" className="underline-offset-4 hover:underline hover:text-ink/70">
+              Aayush Dey
+            </a>
+          </span>
           <span>© {new Date().getFullYear()} Stratosphere</span>
         </div>
       </div>
diff --git a/data.js b/data.js
index 65ae639..80717d2 100644
--- a/data.js
+++ b/data.js
@@ -58,11 +58,7 @@ export const CONTACT = {
     "Jadavpur University",
     "Kolkata - 700032",
   ],
-  hours: [
-    ["Monday - Friday", "9:00 AM - 6:00 PM"],
-    ["Saturday", "10:00 AM - 2:00 PM"],
-    ["Sunday", "Closed"],
-  ],
+  hours: [],
   socials: [
     { platform: "instagram", url: "https://www.instagram.com/aerospace_club_ju", label: "" },
     { platform: "linkedin", url: "https://www.linkedin.com/company/aerospace-club-ju/", label: "" },
-- 
2.43.0


From b0dcfddce0ed89091480c154e3ca559866b90551 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 14/19] test(smoke): black-box HTTP checks for any deployment

Co-authored-by: Claude <noreply@anthropic.com>
---
 tests/smoke/site.test.mjs | 67 +++++++++++++++++++++++++++++++++++++++
 1 file changed, 67 insertions(+)
 create mode 100644 tests/smoke/site.test.mjs

diff --git a/tests/smoke/site.test.mjs b/tests/smoke/site.test.mjs
new file mode 100644
index 0000000..11b25fa
--- /dev/null
+++ b/tests/smoke/site.test.mjs
@@ -0,0 +1,67 @@
+// Black-box checks against a running deployment.
+//   SMOKE_URL=https://preview-url npm run test:smoke
+// Optional: VERCEL_AUTOMATION_BYPASS_SECRET (protected previews),
+//           ADMIN_PATH (custom admin path; /admin must then be a 404).
+import { describe, expect, it } from "vitest";
+
+const BASE = (process.env.SMOKE_URL || "").replace(/\/+$/, "");
+const suite = BASE ? describe : describe.skip;
+const headers = process.env.VERCEL_AUTOMATION_BYPASS_SECRET
+  ? { "x-vercel-protection-bypass": process.env.VERCEL_AUTOMATION_BYPASS_SECRET }
+  : {};
+const get = (path) => fetch(`${BASE}${path}`, { headers, redirect: "manual" });
+
+suite(`smoke: ${BASE}`, () => {
+  let home;
+  let html = "";
+
+  it("home page loads", async () => {
+    home = await get("/");
+    html = await home.text();
+    expect(home.status).toBe(200);
+    expect(html).toContain("Stratosphere");
+  });
+
+  it("sends security headers", () => {
+    expect(home.headers.get("x-content-type-options")).toBe("nosniff");
+    expect(home.headers.get("content-security-policy")).toContain("frame-ancestors 'none'");
+    expect(home.headers.get("x-powered-by")).toBeNull();
+  });
+
+  it("has share and search metadata", () => {
+    expect(html).toMatch(/<meta property="og:image"/);
+    expect(html).toMatch(/<meta name="twitter:card"/);
+    expect(html).toContain('"@type":"Organization"');
+  });
+
+  it("leaks no email addresses beyond the ones shown as mailto links", () => {
+    const shown = new Set([...html.matchAll(/mailto:([^"'?\s]+)/gi)].map((m) => decodeURIComponent(m[1]).toLowerCase()));
+    const found = new Set([...html.matchAll(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)].map((m) => m[0].toLowerCase()));
+    const hidden = [...found].filter((e) => !shown.has(e) && !/@example\.(com|org|net)$/.test(e) && !/\.(png|jpe?g|webp|svg|gif)$/.test(e));
+    expect(hidden).toEqual([]);
+  });
+
+  it("robots.txt and sitemap.xml are served", async () => {
+    const robots = await get("/robots.txt");
+    expect(robots.status).toBe(200);
+    expect(await robots.text()).toMatch(/Sitemap:/i);
+    expect((await get("/sitemap.xml")).status).toBe(200);
+  });
+
+  it("event pages from the sitemap load", async () => {
+    const xml = await (await get("/sitemap.xml")).text();
+    const event = [...xml.matchAll(/<loc>([^<]*\/events\/[^<]+)<\/loc>/g)][0]?.[1];
+    if (!event) return;
+    const res = await get(new URL(event).pathname);
+    expect(res.status).toBe(200);
+  });
+
+  it("unknown pages return 404", async () => {
+    expect((await get("/this-page-does-not-exist-404")).status).toBe(404);
+  });
+
+  it("the default admin path is hidden when a custom one is set", async () => {
+    if (!process.env.ADMIN_PATH || process.env.ADMIN_PATH === "admin") return;
+    expect((await get("/admin")).status).toBe(404);
+  });
+});
-- 
2.43.0


From 9d3aa66d9d72aa384c5e91488d472b594a25a3b2 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 15/19] ci: lint, unit, build, RLS, append-only migrations,
 secret scan, audit

Co-authored-by: Claude <noreply@anthropic.com>
---
 .github/workflows/ci.yml | 97 ++++++++++++++++++++++++++++++++++++++++
 1 file changed, 97 insertions(+)
 create mode 100644 .github/workflows/ci.yml

diff --git a/.github/workflows/ci.yml b/.github/workflows/ci.yml
new file mode 100644
index 0000000..07ef572
--- /dev/null
+++ b/.github/workflows/ci.yml
@@ -0,0 +1,97 @@
+name: CI
+
+on:
+  pull_request:
+  push:
+    branches: [main]
+
+permissions:
+  contents: read
+
+concurrency:
+  group: ci-${{ github.ref }}
+  cancel-in-progress: true
+
+jobs:
+  check:
+    name: Lint, unit tests, build
+    runs-on: ubuntu-latest
+    timeout-minutes: 15
+    steps:
+      - uses: actions/checkout@v4
+      - uses: actions/setup-node@v4
+        with:
+          node-version: 22
+          cache: npm
+      - run: npm ci
+      - run: npm run lint
+      - run: npm run test:unit
+      - run: npm run build
+        env:
+          NEXT_TELEMETRY_DISABLED: 1
+
+  database:
+    name: Database security (RLS)
+    runs-on: ubuntu-latest
+    timeout-minutes: 10
+    services:
+      postgres:
+        image: postgres:17
+        env:
+          POSTGRES_PASSWORD: postgres
+        ports: ["5432:5432"]
+        options: >-
+          --health-cmd "pg_isready -U postgres"
+          --health-interval 5s --health-timeout 5s --health-retries 10
+    steps:
+      - uses: actions/checkout@v4
+      - uses: actions/setup-node@v4
+        with:
+          node-version: 22
+          cache: npm
+      - run: npm ci
+      - run: npm run test:db
+        env:
+          TEST_DATABASE_URL: postgres://postgres:postgres@localhost:5432/postgres
+
+  migrations:
+    name: Migrations are append-only
+    if: github.event_name == 'pull_request'
+    runs-on: ubuntu-latest
+    steps:
+      - uses: actions/checkout@v4
+        with:
+          fetch-depth: 0
+      - name: Fail if an existing migration was edited, renamed or deleted
+        run: |
+          changed=$(git diff --name-status "origin/${{ github.base_ref }}...HEAD" -- supabase/migrations | grep -E '^(M|D|R)' || true)
+          if [ -n "$changed" ]; then
+            echo "::error::Applied migrations must never change. Add a new numbered file instead."
+            echo "$changed"
+            exit 1
+          fi
+
+  secrets:
+    name: Secret scan
+    runs-on: ubuntu-latest
+    steps:
+      - uses: actions/checkout@v4
+        with:
+          fetch-depth: 0
+      - uses: gitleaks/gitleaks-action@v2
+        env:
+          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
+
+  audit:
+    name: Dependency audit
+    runs-on: ubuntu-latest
+    steps:
+      - uses: actions/checkout@v4
+      - uses: actions/setup-node@v4
+        with:
+          node-version: 22
+      # Blocks on critical. The remaining "high" is postcss bundled inside
+      # next@15 (build-time only); it clears with the Next 16 upgrade.
+      - run: npm audit --omit=dev --audit-level=critical
+      - name: Report high-severity advisories (non-blocking)
+        run: npm audit --omit=dev --audit-level=high || echo "::warning::High-severity advisories present; see the log above."
-- 
2.43.0


From 68436c8d2bdedfdeb385ba6aab70235bad6a88d0 Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 16/19] ci: smoke-test every Vercel deployment and run a
 30-minute uptime check

Co-authored-by: Claude <noreply@anthropic.com>
---
 .github/workflows/deploy-smoke.yml | 42 ++++++++++++++++++++
 .github/workflows/uptime.yml       | 61 ++++++++++++++++++++++++++++++
 2 files changed, 103 insertions(+)
 create mode 100644 .github/workflows/deploy-smoke.yml
 create mode 100644 .github/workflows/uptime.yml

diff --git a/.github/workflows/deploy-smoke.yml b/.github/workflows/deploy-smoke.yml
new file mode 100644
index 0000000..a42e097
--- /dev/null
+++ b/.github/workflows/deploy-smoke.yml
@@ -0,0 +1,42 @@
+name: Deployment smoke test
+
+# Vercel reports every deployment (preview and production) to GitHub.
+# When one finishes, hit it with real HTTP requests.
+on:
+  deployment_status:
+
+permissions:
+  contents: read
+  issues: write
+
+jobs:
+  smoke:
+    if: github.event.deployment_status.state == 'success'
+    runs-on: ubuntu-latest
+    timeout-minutes: 10
+    steps:
+      - uses: actions/checkout@v4
+        with:
+          ref: ${{ github.event.deployment.sha }}
+      - uses: actions/setup-node@v4
+        with:
+          node-version: 22
+          cache: npm
+      - run: npm ci
+      - run: npm run test:smoke
+        env:
+          SMOKE_URL: ${{ github.event.deployment_status.environment_url || github.event.deployment_status.target_url }}
+          VERCEL_AUTOMATION_BYPASS_SECRET: ${{ secrets.VERCEL_AUTOMATION_BYPASS_SECRET }}
+          ADMIN_PATH: ${{ secrets.ADMIN_PATH }}
+      - name: Open a P0 issue when production fails its smoke test
+        if: failure() && github.event.deployment.environment == 'Production'
+        uses: actions/github-script@v7
+        with:
+          script: |
+            await github.rest.issues.create({
+              owner: context.repo.owner,
+              repo: context.repo.repo,
+              title: `P0: production deploy ${context.payload.deployment.sha.slice(0, 7)} failed smoke tests`,
+              body: `Deployment: ${context.payload.deployment_status.environment_url}\nRun: ${context.serverUrl}/${context.repo.owner}/${context.repo.repo}/actions/runs/${context.runId}\n\nRoll back in Vercel (Deployments → previous → Promote) if users are affected.`,
+              labels: ["P0", "incident"],
+            });
diff --git a/.github/workflows/uptime.yml b/.github/workflows/uptime.yml
new file mode 100644
index 0000000..6e80ee7
--- /dev/null
+++ b/.github/workflows/uptime.yml
@@ -0,0 +1,61 @@
+name: Uptime and data-exposure check
+
+# Every 30 minutes: is the site up, and can the public anon key read anything
+# private? Opens one P0 issue on failure (and keeps the free Supabase project
+# from pausing for inactivity).
+on:
+  schedule:
+    - cron: "*/30 * * * *"
+  workflow_dispatch:
+
+permissions:
+  contents: read
+  issues: write
+
+jobs:
+  check:
+    runs-on: ubuntu-latest
+    timeout-minutes: 5
+    steps:
+      - name: Site is up
+        env:
+          SITE: ${{ vars.PROD_URL }}
+        run: |
+          for path in / /sitemap.xml; do
+            code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 "$SITE$path")
+            echo "$path -> $code"
+            [ "$code" = 200 ] || { echo "::error::$path returned $code"; exit 1; }
+          done
+      - name: Anon key cannot read private data
+        env:
+          SUPABASE_URL: ${{ vars.PROD_SUPABASE_URL }}
+          ANON_KEY: ${{ secrets.PROD_SUPABASE_ANON_KEY }}
+        run: |
+          read_as_anon() {
+            curl -s --max-time 20 -o /tmp/body -w '%{http_code}' "$SUPABASE_URL/rest/v1/$1" \
+              -H "apikey: $ANON_KEY" -H "Authorization: Bearer $ANON_KEY"
+          }
+          for path in "contact_messages?select=id&limit=1" "profiles?select=id&limit=1" "media?select=id&limit=1"; do
+            code=$(read_as_anon "$path")
+            if [ "$code" = 200 ] && [ "$(cat /tmp/body)" != "[]" ]; then
+              echo "::error::Anon can read $path"; exit 1
+            fi
+          done
+          code=$(read_as_anon "cohort_members?select=email&limit=1")
+          if [ "$code" = 200 ]; then echo "::error::Anon can read member emails (apply migration 0008)"; exit 1; fi
+      - name: Open a P0 issue (once)
+        if: failure()
+        uses: actions/github-script@v7
+        with:
+          script: |
+            const open = await github.rest.issues.listForRepo({
+              owner: context.repo.owner, repo: context.repo.repo, state: "open", labels: "uptime",
+            });
+            if (open.data.length) return;
+            await github.rest.issues.create({
+              owner: context.repo.owner,
+              repo: context.repo.repo,
+              title: "P0: uptime / data-exposure check failing",
+              body: `Run: ${context.serverUrl}/${context.repo.owner}/${context.repo.repo}/actions/runs/${context.runId}`,
+              labels: ["P0", "uptime", "incident"],
+            });
-- 
2.43.0


From 6f26d1e3aa4cbd68db7403011164c6c0bbb9195f Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 17/19] ci: add CodeQL, Dependabot and a PR template

Co-authored-by: Claude <noreply@anthropic.com>
---
 .github/dependabot.yml           | 14 ++++++++++++++
 .github/pull_request_template.md | 10 ++++++++++
 .github/workflows/codeql.yml     | 23 +++++++++++++++++++++++
 3 files changed, 47 insertions(+)
 create mode 100644 .github/dependabot.yml
 create mode 100644 .github/pull_request_template.md
 create mode 100644 .github/workflows/codeql.yml

diff --git a/.github/dependabot.yml b/.github/dependabot.yml
new file mode 100644
index 0000000..bed2ce8
--- /dev/null
+++ b/.github/dependabot.yml
@@ -0,0 +1,14 @@
+version: 2
+updates:
+  - package-ecosystem: npm
+    directory: /
+    schedule:
+      interval: weekly
+    open-pull-requests-limit: 5
+    groups:
+      minor-and-patch:
+        update-types: [minor, patch]
+  - package-ecosystem: github-actions
+    directory: /
+    schedule:
+      interval: weekly
diff --git a/.github/pull_request_template.md b/.github/pull_request_template.md
new file mode 100644
index 0000000..62ce50d
--- /dev/null
+++ b/.github/pull_request_template.md
@@ -0,0 +1,10 @@
+## What changed
+
+## Why
+
+## Checklist
+- [ ] One concern per PR, atomic commits with Conventional Commit messages
+- [ ] Tests added or updated (unit, `tests/db` for policy changes, smoke for page changes)
+- [ ] New database change is a **new** numbered migration (never edit an applied one)
+- [ ] Migration order noted if it must run before/after the deploy
+- [ ] No secrets, keys or personal data in the diff
diff --git a/.github/workflows/codeql.yml b/.github/workflows/codeql.yml
new file mode 100644
index 0000000..56f1a75
--- /dev/null
+++ b/.github/workflows/codeql.yml
@@ -0,0 +1,23 @@
+name: CodeQL
+
+on:
+  push:
+    branches: [main]
+  pull_request:
+  schedule:
+    - cron: "17 3 * * 1"
+
+permissions:
+  contents: read
+  security-events: write
+
+jobs:
+  analyze:
+    runs-on: ubuntu-latest
+    steps:
+      - uses: actions/checkout@v4
+      - uses: github/codeql-action/init@v3
+        with:
+          languages: javascript-typescript
+          queries: security-and-quality
+      - uses: github/codeql-action/analyze@v3
-- 
2.43.0


From 38f1b9b81f349828f59c2e47d854f5194d36083b Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 18/19] chore: dedupe .gitignore, keep .env.example, mark
 seed-only env vars

Co-authored-by: Claude <noreply@anthropic.com>
---
 .env.example | 1 +
 .gitignore   | 3 +--
 2 files changed, 2 insertions(+), 2 deletions(-)

diff --git a/.env.example b/.env.example
index aeefac9..31de663 100644
--- a/.env.example
+++ b/.env.example
@@ -36,6 +36,7 @@ NEXT_PUBLIC_SITE_URL=
 # After the first run, change the password from the dashboard and clear
 # ADMIN_PASSWORD out of this file. Every account after this one is created
 # from the Accounts tab, not from here.
+# Local seeding only (npm run seed). Never set these on Vercel: production never reads them.
 ADMIN_NAME=Club Admin
 ADMIN_EMAIL=
 ADMIN_PASSWORD=
diff --git a/.gitignore b/.gitignore
index 618bac1..bdfea9f 100644
--- a/.gitignore
+++ b/.gitignore
@@ -5,6 +5,7 @@ build
 .dist
 
 .env
+!.env.example
 .env.local
 .env*.local
 
@@ -16,9 +17,7 @@ next-env.d.ts
 npm-debug.log*
 .claude
 
-.vercel
 .env*
 .mcp.json
 components.json
 .playwright-mcp
-.claude
-- 
2.43.0


From 7cfbf79aa2003b2a105d23a8b613a4563745b00e Mon Sep 17 00:00:00 2001
From: deyaayush2006-coder <25f2004526@ds.study.iitm.ac.in>
Date: Thu, 8 Oct 2026 03:31:53 +0000
Subject: [PATCH 19/19] docs: security model, migrations, testing and CI/CD
 runbook

Co-authored-by: Claude <noreply@anthropic.com>
---
 README.md | 44 ++++++++++++++++++++++++++++++++++++++++++++
 1 file changed, 44 insertions(+)

diff --git a/README.md b/README.md
index 2276537..902ba97 100644
--- a/README.md
+++ b/README.md
@@ -211,3 +211,47 @@ few hundred points and a set of finished numbers, not the raw log and a parser
 to run over it. `three` and `recharts` are loaded only by the pages that
 actually draw something, so a project with none of these extras pays nothing
 for them.
+
+
+## Security model
+
+- **Public site** reads Supabase with the anon key. RLS lets `anon` read published content only. Member emails, contact messages, profiles, drafts and the media table are never readable by `anon`.
+- **Staff** are accounts whose `profiles.is_active` is true. Only the server (service role) can create staff: the admin panel sets `app_metadata.staff` / `app_metadata.role`, which users cannot edit. Public sign-ups get an inactive profile and see nothing.
+- **Keep public sign-ups off** in Supabase → Authentication → Sign In / Providers. Migration 0007 makes a sign-up harmless, but there is no reason to allow it.
+- Role checks (`private.is_staff()`, `private.is_admin()`) live in a schema the REST API does not expose.
+- Security headers come from `lib/security-headers.mjs`. The full CSP runs in Report-Only mode; move it to the enforced header once a preview deploy shows no violations in the browser console.
+
+## Migrations
+
+Migrations are append-only: never edit a file that has been applied; add a new numbered one. CI fails a PR that changes an existing migration.
+
+| File | When to apply |
+| --- | --- |
+| `0007_auth_and_rls_hardening.sql` | Any time (no app change needed). Until this app version is live, accounts created in Control Tower start suspended; activate them under Users. |
+| `0008_member_email_privacy.sql` | **Only after** this app version is deployed. The old code selects `cohort_members(*)`, which fails once anon loses the email column. |
+
+## Testing
+
+| Command | What it checks | Needs |
+| --- | --- | --- |
+| `npm run lint` | ESLint (Next.js rules) | — |
+| `npm run test:unit` | Content privacy, admin save rollback, contact form, security headers, event dates | — |
+| `npm run test:db` | Every RLS policy, as anon, outsider, suspended editor, editor and admin, on plain Postgres with all migrations | `TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/postgres` |
+| `npm run test:smoke` | Black-box HTTP checks of a running site (status codes, headers, metadata, no leaked emails) | `SMOKE_URL=https://…` |
+
+## CI/CD
+
+1. **Pull request → GitHub Actions (`ci.yml`)**: lint, unit tests, build, RLS tests on Postgres 17, append-only migration check, gitleaks secret scan, `npm audit`. CodeQL runs separately.
+2. **Vercel build**: `vercel-build` runs lint and unit tests before `next build`, so a failing test fails the deploy and production keeps the last good version.
+3. **Every Vercel deployment → `deploy-smoke.yml`**: smoke tests against the preview or production URL. A failing production smoke test opens a `P0` issue.
+4. **Every 30 minutes → `uptime.yml`**: site up, and the anon key cannot read private data. Opens one `P0` issue on failure.
+5. **Dependabot** opens weekly update PRs, which go through the same checks.
+
+One-time setup:
+- GitHub → Settings → Branches: protect `main`; require a PR and the `Lint, unit tests, build`, `Database security (RLS)`, `Migrations are append-only` and `Secret scan` checks.
+- GitHub → Settings → Secrets and variables → Actions: secrets `VERCEL_AUTOMATION_BYPASS_SECRET` (if Deployment Protection is on), `ADMIN_PATH`, `PROD_SUPABASE_ANON_KEY`; variables `PROD_URL`, `PROD_SUPABASE_URL`.
+- Vercel: delete `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME` (only `npm run seed` uses them, locally).
+
+## Contributing
+
+Branch from `main` (`fix/…`, `feat/…`, `ci/…`), keep commits atomic with Conventional Commit messages, open a PR, merge when CI is green.
-- 
2.43.0

STRATOSPHERE-MBOX-END
````
